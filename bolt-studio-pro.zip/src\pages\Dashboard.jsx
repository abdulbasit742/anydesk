import { useStore } from '../data/store';
import { PLATFORMS } from '../data/constants';
import { PlatformIcon, StatusBadge } from '../components/PlatformBadge';

function ago(iso) {
  if (!iso) return 'Never';
  const d = (Date.now() - new Date(iso)) / 1000;
  if (d < 60) return 'Just now';
  if (d < 3600) return ~~(d / 60) + 'm ago';
  if (d < 86400) return ~~(d / 3600) + 'h ago';
  return ~~(d / 86400) + 'd ago';
}

export default function Dashboard({ onNav, onConnect }) {
  const { accounts, broadcasts, projects, prompts } = useStore();
  const total = accounts.length;
  const active = accounts.filter(a => a.status === 'active').length;
  const totalBc = broadcasts.length;
  const todayBc = broadcasts.filter(b => new Date(b.createdAt).toDateString() === new Date().toDateString()).length;

  if (!total) {
    return (
      <div style={{ maxWidth: 540, margin: '40px auto', textAlign: 'center' }}>
        <div style={{ fontSize: 52, marginBottom: 18 }}>⚡</div>
        <div style={{ fontSize: 24, fontWeight: 800, color: '#fff', marginBottom: 10, letterSpacing: '-.5px' }}>Welcome to Bolt Studio Pro</div>
        <div style={{ fontSize: 14, color: 'var(--muted)', lineHeight: 1.7, marginBottom: 28 }}>
          Connect your first AI platform account to get started.<br />All data shown here will be real — only what you add.
        </div>
        <div style={{ display: 'flex', gap: 10, justifyContent: 'center', flexWrap: 'wrap' }}>
          <button className="btn btn-gold" style={{ fontSize: 14, padding: '10px 22px' }} onClick={onConnect}>⚡ Connect Account</button>
          <button className="btn btn-ghost" onClick={() => onNav('accounts')}>+ Add Manually</button>
        </div>
        <div className="card" style={{ marginTop: 36, textAlign: 'left' }}>
          <div className="card-title" style={{ marginBottom: 12 }}>What you'll get</div>
          {[
            ['📡', 'Broadcast to all platforms at once', 'Send one prompt to all your AI accounts simultaneously'],
            ['📁', 'Manage real projects', 'Track your actual projects across platforms'],
            ['✨', 'AI Prompt Optimizer', 'Enhance prompts with AI before broadcasting'],
            ['⚙', 'Workflow Automation', 'Build multi-step prompt sequences'],
          ].map(([ic, t, d]) => (
            <div key={t} style={{ display: 'flex', gap: 12, marginBottom: 12, alignItems: 'flex-start' }}>
              <div style={{ fontSize: 18, flexShrink: 0, marginTop: 1 }}>{ic}</div>
              <div>
                <div style={{ fontSize: 13, fontWeight: 700, color: '#e2e2ec', marginBottom: 2 }}>{t}</div>
                <div style={{ fontSize: 12, color: 'var(--muted)' }}>{d}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  const recentBc = broadcasts.slice(0, 5);
  const accList = accounts.slice(0, 6);

  return (
    <>
      <div className="stats-row">
        <div className="stat" style={{ '--ac': 'var(--blue)' }}><div className="lbl">Accounts</div><div className="val">{total}</div><div className="sub">{active} active</div></div>
        <div className="stat" style={{ '--ac': 'var(--gold)' }}><div className="lbl">Broadcasts</div><div className="val" style={{ color: 'var(--gold)' }}>{totalBc}</div><div className="sub">{todayBc} today</div></div>
        <div className="stat" style={{ '--ac': 'var(--teal)' }}><div className="lbl">Projects</div><div className="val" style={{ color: 'var(--teal)' }}>{projects.length}</div><div className="sub">workspaces</div></div>
        <div className="stat" style={{ '--ac': '#a78bfa' }}><div className="lbl">Prompts Saved</div><div className="val" style={{ color: '#a78bfa' }}>{prompts.length}</div><div className="sub">in library</div></div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
        <div className="card">
          <div className="card-hdr"><span className="card-title">My Accounts ({total})</span><button className="btn btn-ghost btn-xs" onClick={() => onNav('accounts')}>Manage →</button></div>
          {accList.map(a => {
            const pl = PLATFORMS.find(p => p.id === a.platform) || PLATFORMS[0];
            return (
              <div key={a.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 0', borderBottom: '1px solid var(--border)' }}>
                <PlatformIcon platformId={a.platform} size={24} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: '#e2e2ec', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{a.name}</div>
                  <div style={{ fontSize: 11, color: 'var(--muted)' }}>{a.email || pl.name}</div>
                </div>
                <StatusBadge status={a.status} />
              </div>
            );
          })}
          {total > 6 && <div style={{ textAlign: 'center', padding: '8px 0', fontSize: 11, color: 'var(--muted)' }}>+{total - 6} more accounts</div>}
        </div>
        <div className="card">
          <div className="card-hdr"><span className="card-title">Recent Broadcasts</span><button className="btn btn-ghost btn-xs" onClick={() => onNav('broadcast')}>+ New →</button></div>
          {recentBc.length ? recentBc.map(b => (
            <div key={b.id} style={{ padding: '9px 0', borderBottom: '1px solid var(--border)' }}>
              <div className="mono" style={{ fontSize: 11.5, color: '#d0d0e0', overflow: 'hidden', whiteSpace: 'nowrap', textOverflow: 'ellipsis' }}>
                {b.prompt?.slice(0, 70)}{b.prompt?.length > 70 ? '…' : ''}
              </div>
              <div style={{ display: 'flex', gap: 8, marginTop: 3 }}>
                <span style={{ fontSize: 10.5, color: 'var(--muted)' }}>{ago(b.createdAt)}</span>
                <span style={{ fontSize: 10.5, color: 'var(--teal)' }}>✓ {b.successCount || 0}</span>
                {b.failureCount > 0 && <span style={{ fontSize: 10.5, color: 'var(--red)' }}>✕ {b.failureCount}</span>}
              </div>
            </div>
          )) : (
            <div style={{ padding: '20px 0', textAlign: 'center', color: 'var(--muted)', fontSize: 12 }}>No broadcasts yet</div>
          )}
        </div>
      </div>
      <div className="card" style={{ marginTop: 14 }}>
        <div className="card-hdr"><span className="card-title">Quick Actions</span></div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <button className="btn btn-gold" onClick={onConnect}>⚡ Connect Account</button>
          <button className="btn btn-teal" onClick={() => onNav('broadcast')}>📡 Broadcast</button>
          <button className="btn btn-ghost" onClick={() => onNav('optimizer')}>✨ Optimize Prompt</button>
          <button className="btn btn-ghost" onClick={() => onNav('projects')}>📁 Projects</button>
        </div>
      </div>
    </>
  );
}
