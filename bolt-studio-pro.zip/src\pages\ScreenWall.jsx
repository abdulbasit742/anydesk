import { useState, useRef, useEffect } from 'react';
import { useStore } from '../data/store';
import { PLATFORMS } from '../data/constants';
import { PlatformIcon, StatusBadge } from '../components/PlatformBadge';
import { useToast } from '../components/Toast';
import { getSavedClientId, launchGoogleOAuth } from '../lib/googleAuth';
import GoogleClientIdSetup from '../modals/GoogleClientIdSetup';

const LAYOUTS = [
  { label: 'Auto Grid', cols: null },
  { label: '2 Columns', cols: 2 },
  { label: '3 Columns', cols: 3 },
  { label: '4 Columns', cols: 4 },
];

// Staggered log lines that print when a prompt is broadcasting
const LOG_TEMPLATES = [
  "[SYS] Initializing container shell...",
  "[AUTH] Authenticated via Google Session...",
  "[SYNC] Syncing workspace with Lovable...",
  "[CODE] Applying prompt instructions...",
  "[BUILD] React modules compiled clean.",
  "[DEPL] Deployed to sandbox successfully!",
];

// Helper to calculate time ago
function ago(iso) {
  if (!iso) return 'Never';
  const d = (Date.now() - new Date(iso)) / 1000;
  if (d < 60) return 'Just now';
  if (d < 3600) return ~~(d / 60) + 'm ago';
  if (d < 86400) return ~~(d / 3600) + 'h ago';
  return ~~(d / 86400) + 'd ago';
}

function ScreenCard({ account, index, onConnect, isSending, sendStatus, prompt, onGoogleConnectClick, onManualConnect }) {
  const pl = PLATFORMS.find(p => p.id === account?.platform) || PLATFORMS[0];
  const [terminalLogs, setTerminalLogs] = useState(["SYSTEM READY. AWAITING BROADCAST..."]);
  const [logIndex, setLogIndex] = useState(0);

  // States for mini inline login inside the standby screen shell
  const [selectedPlatform, setSelectedPlatform] = useState(() => PLATFORMS[index % PLATFORMS.length].id);
  const [showManual, setShowManual] = useState(false);
  const [manualEmail, setManualEmail] = useState('');
  const [manualCred, setManualCred] = useState('');
  const [manualLoading, setManualLoading] = useState(false);

  const selPl = PLATFORMS.find(x => x.id === selectedPlatform) || PLATFORMS[0];

  // Animate the terminal logs when broadcast is sending to this specific screen
  useEffect(() => {
    if (isSending && sendStatus === 'sending') {
      setTerminalLogs([`> RUN PROMPT: "${prompt || 'Syncing changes...'}"`]);
      setLogIndex(0);
    }
  }, [isSending, sendStatus, prompt]);

  useEffect(() => {
    if (isSending && sendStatus === 'sending' && logIndex < LOG_TEMPLATES.length) {
      const delay = 350 + Math.random() * 250; 
      const timer = setTimeout(() => {
        setTerminalLogs(prev => [...prev, `> ${LOG_TEMPLATES[logIndex]}`]);
        setLogIndex(prev => prev + 1);
      }, delay);
      return () => clearTimeout(timer);
    }
  }, [isSending, sendStatus, logIndex]);

  // Handle final state print
  useEffect(() => {
    if (!isSending) {
      if (sendStatus === 'success') {
        setTerminalLogs(prev => [...prev, "✓ BROADCAST SUCCESSFUL.", "ACTIVE SANDBOX LIVE."]);
      } else if (sendStatus === 'error') {
        setTerminalLogs(prev => [...prev, "✕ BROADCAST FAILED.", "VERIFY SESSION CREDENTIALS."]);
      }
    }
  }, [isSending, sendStatus]);

  // Handle manual connect
  const handleManualSave = async (e) => {
    e.preventDefault();
    if (!manualCred.trim()) return;
    setManualLoading(true);
    await new Promise(r => setTimeout(r, 600));
    onManualConnect({
      platform: selectedPlatform,
      name: `${selPl.name} Screen`,
      email: manualEmail.trim() || `${selectedPlatform}@workspace.dev`,
      token: '••••' + manualCred.slice(-4),
    });
    setManualLoading(false);
    setShowManual(false);
    setManualCred('');
  };

  // Render standby frame with direct login buttons for empty slots
  if (!account) {
    return (
      <div
        style={{
          background: 'rgba(14, 14, 22, 0.45)',
          border: '1px solid rgba(255, 255, 255, 0.05)',
          borderRadius: '12px',
          display: 'flex',
          flexDirection: 'column',
          minHeight: 250,
          color: 'var(--muted)',
          position: 'relative',
          overflow: 'hidden',
          backdropFilter: 'blur(10px)',
          transition: 'all 0.2s',
        }}
      >
        {/* Mock Chrome Window Header */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: 6,
          padding: '8px 12px',
          background: 'rgba(20, 20, 31, 0.65)',
          borderBottom: '1px solid rgba(255,255,255,0.04)',
        }}>
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#6b6b82' }} />
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#6b6b82' }} />
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#6b6b82' }} />
          <div style={{
            flex: 1,
            background: 'rgba(0,0,0,0.2)',
            borderRadius: 4,
            fontSize: 9,
            padding: '2px 8px',
            color: 'var(--muted)',
            textAlign: 'center',
            fontFamily: 'DM Mono, monospace',
            marginLeft: 12,
          }}>
            tab://empty-slot-{index + 1}
          </div>
        </div>

        {/* Viewport Content */}
        <div style={{
          flex: 1,
          display: 'flex',
          flexDirection: 'column',
          padding: '12px 14px',
          justifyContent: 'center',
        }}>
          
          <div style={{
            fontSize: 9,
            fontWeight: 800,
            letterSpacing: '0.08em',
            color: 'var(--gold)',
            textTransform: 'uppercase',
            textAlign: 'center',
            marginBottom: 6,
          }}>
            SCREEN {index + 1} · CONSOLE STANDBY
          </div>

          {!showManual ? (
            <>
              {/* Step 1: Horizontal Platform selector mini-icons */}
              <div style={{
                display: 'flex',
                gap: 4,
                justifyContent: 'center',
                marginBottom: 10,
                flexWrap: 'wrap',
              }}>
                {PLATFORMS.map(p => (
                  <button
                    key={p.id}
                    title={p.name}
                    onClick={() => setSelectedPlatform(p.id)}
                    style={{
                      cursor: 'pointer',
                      padding: '4px 6px',
                      borderRadius: 6,
                      fontSize: 11,
                      background: selectedPlatform === p.id ? p.bg : 'rgba(255,255,255,0.02)',
                      border: `1px solid ${selectedPlatform === p.id ? p.color : 'rgba(255,255,255,0.06)'}`,
                      opacity: selectedPlatform === p.id ? 1 : 0.5,
                      transition: 'all 0.15s',
                    }}
                  >
                    {p.icon}
                  </button>
                ))}
              </div>

              {/* Step 2: Direct Google Connect button in every small screen */}
              <button
                type="button"
                onClick={() => onGoogleConnectClick(selectedPlatform)}
                style={{
                  width: '100%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 8,
                  padding: '8px 12px',
                  background: '#ffffff',
                  color: '#1f1f1f',
                  fontFamily: '"Syne", sans-serif',
                  fontWeight: 700,
                  fontSize: 11,
                  border: 'none',
                  borderRadius: 6,
                  cursor: 'pointer',
                  boxShadow: '0 2px 4px rgba(0,0,0,0.2)',
                  transition: 'all 0.2s',
                  marginBottom: 8,
                }}
                onMouseEnter={e => { e.currentTarget.style.background = '#f1f3f4'; }}
                onMouseLeave={e => { e.currentTarget.style.background = '#ffffff'; }}
              >
                <svg viewBox="0 0 24 24" width="13" height="13" style={{ flexShrink: 0 }}>
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.56-2.77c-.98.66-2.23 1.06-3.72 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                </svg>
                Sign in with Google
              </button>

              {/* Or switch to manual */}
              <div style={{ textAlign: 'center' }}>
                <button
                  onClick={() => setShowManual(true)}
                  style={{
                    background: 'none',
                    border: 'none',
                    fontSize: 9.5,
                    color: 'var(--muted2)',
                    textDecoration: 'underline',
                    cursor: 'pointer',
                  }}
                >
                  Or use Token/Credentials
                </button>
              </div>
            </>
          ) : (
            /* Inline manual token form */
            <form onSubmit={handleManualSave} style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <div style={{ fontSize: 9, color: 'var(--muted)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span>🔑 Connect {selPl.name} manually:</span>
                <span
                  onClick={() => setShowManual(false)}
                  style={{ color: 'var(--red)', cursor: 'pointer', textDecoration: 'underline' }}
                >
                  Back
                </span>
              </div>
              <input
                type="email"
                placeholder="yourname@gmail.com"
                value={manualEmail}
                onChange={e => setManualEmail(e.target.value)}
                style={{ padding: '4px 8px', fontSize: 10, background: 'var(--surface3)', color: '#fff', border: '1px solid var(--border)', borderRadius: 4 }}
              />
              <input
                type="password"
                placeholder={selPl.credPlaceholder}
                value={manualCred}
                onChange={e => setManualCred(e.target.value)}
                required
                style={{ padding: '4px 8px', fontSize: 10, background: 'var(--surface3)', color: '#fff', border: '1px solid var(--border)', borderRadius: 4, fontFamily: 'DM Mono, monospace' }}
              />
              <button
                type="submit"
                disabled={manualLoading}
                className="btn btn-gold btn-xs"
                style={{ width: '100%', justifyContent: 'center', fontSize: 9.5, padding: '4px 0' }}
              >
                {manualLoading ? '⏳ Saving' : `⚡ Save Connection`}
              </button>
            </form>
          )}

        </div>
      </div>
    );
  }

  const creditPct = account.creditLimit > 0
    ? Math.min(100, Math.round((account.creditBalance / account.creditLimit) * 100))
    : 100;

  const statusBorderColor = sendStatus === 'success' ? 'var(--teal)'
    : sendStatus === 'error' ? 'var(--red)'
    : sendStatus === 'sending' ? 'var(--gold)'
    : 'rgba(255, 255, 255, 0.08)';

  const accentColor = sendStatus === 'success' ? 'var(--teal)'
    : sendStatus === 'error' ? 'var(--red)'
    : sendStatus === 'sending' ? 'var(--gold)'
    : pl.color;

  return (
    <div
      style={{
        background: 'var(--surface2)',
        border: `1px solid ${statusBorderColor}`,
        borderRadius: '12px',
        display: 'flex',
        flexDirection: 'column',
        minHeight: 250,
        position: 'relative',
        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
        overflow: 'hidden',
        boxShadow: sendStatus === 'sending' ? '0 0 20px rgba(245, 183, 49, 0.12)' 
                 : sendStatus === 'success' ? '0 0 20px rgba(0, 212, 170, 0.12)'
                 : 'none',
      }}
      onMouseEnter={e => {
        if (!isSending) {
          e.currentTarget.style.transform = 'translateY(-2px)';
          e.currentTarget.style.borderColor = accentColor;
          e.currentTarget.style.boxShadow = `0 6px 20px ${accentColor}11`;
        }
      }}
      onMouseLeave={e => {
        if (!isSending) {
          e.currentTarget.style.transform = 'translateY(0)';
          e.currentTarget.style.borderColor = statusBorderColor;
          e.currentTarget.style.boxShadow = 'none';
        }
      }}
    >
      {/* 🟢 Mock Chrome Tab Header */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: 6,
        padding: '8px 12px',
        background: 'rgba(20, 20, 31, 0.8)',
        borderBottom: '1px solid rgba(255,255,255,0.06)',
      }}>
        {/* Window controls */}
        <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#ff5f5f' }} />
        <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#f5b731' }} />
        <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#00d4aa' }} />
        
        {/* Mock Address Bar */}
        <div style={{
          flex: 1,
          background: 'rgba(0,0,0,0.3)',
          border: '1px solid rgba(255, 255, 255, 0.04)',
          borderRadius: '4px',
          fontSize: 9,
          padding: '2px 10px',
          color: 'rgba(255,255,255,0.6)',
          textAlign: 'left',
          fontFamily: 'DM Mono, monospace',
          marginLeft: 12,
          display: 'flex',
          alignItems: 'center',
          gap: 4,
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          whiteSpace: 'nowrap',
        }}>
          <span style={{ color: 'var(--teal)', fontSize: 7 }}>🔒</span>
          https://{account.platform}.dev/project/{account.id.slice(0, 6)}
        </div>
      </div>

      {/* Screen Frame Content */}
      <div style={{ padding: '12px 12px 8px', display: 'flex', flexDirection: 'column', gap: 8, flex: 1 }}>
        
        {/* Account Meta Header */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <PlatformIcon platformId={account.platform} size={22} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{
              fontSize: 12,
              fontWeight: 800,
              color: '#fff',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap',
            }}>
              {account.name}
            </div>
            <div style={{ fontSize: 9, color: 'var(--muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {account.email || `${pl.name} Member`}
            </div>
          </div>
          <StatusBadge status={account.status} />
        </div>

        {/* Dynamic Sandbox Terminal Area */}
        <div style={{
          background: '#040406',
          border: '1px solid rgba(255,255,255,0.05)',
          borderRadius: '6px',
          padding: '8px 10px',
          fontFamily: 'DM Mono, monospace',
          fontSize: 8.5,
          color: accentColor,
          flex: 1,
          display: 'flex',
          flexDirection: 'column',
          gap: 4,
          minHeight: 90,
          overflowY: 'auto',
          boxShadow: 'inset 0 0 10px rgba(0,0,0,0.8)',
        }}>
          {terminalLogs.map((log, lIdx) => (
            <div key={lIdx} style={{
              whiteSpace: 'pre-wrap',
              wordBreak: 'break-all',
              opacity: lIdx === terminalLogs.length - 1 ? 1 : 0.65,
              animation: 'fadeIn 0.15s ease',
            }}>
              {log}
            </div>
          ))}
        </div>

        {/* Mini Credit slider & Link */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: 9, color: 'var(--muted)', marginTop: 2 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4, flex: 1, marginRight: 16 }}>
            <span>Credits:</span>
            <div className="progress" style={{ height: 3, flex: 1, marginBottom: 0 }}>
              <div
                className="progress-fill"
                style={{
                  width: `${creditPct}%`,
                  background: creditPct < 20 ? 'var(--red)' : creditPct < 50 ? 'var(--gold)' : `linear-gradient(90deg, var(--gold), var(--teal))`,
                }}
              />
            </div>
            <span style={{ fontWeight: 700, color: pl.color }}>{creditPct}%</span>
          </div>

          <span
            style={{
              color: pl.color,
              fontWeight: 700,
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: 2,
            }}
            onClick={() => window.open(pl.url, '_blank')}
          >
            Open Tab ↗
          </span>
        </div>

      </div>
    </div>
  );
}

export default function ScreenWall({ onConnect }) {
  const { accounts, addAccount, addBroadcast, updateAccount, setState } = useStore();
  const toast = useToast();

  const [layout, setLayout] = useState('Auto Grid');
  const [prompt, setPrompt] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [sendProgress, setSendProgress] = useState(0);
  const [sendStatuses, setSendStatuses] = useState({}); 
  const [showPromptBar, setShowPromptBar] = useState(true);
  const promptRef = useRef(null);

  // States for real Google login from empty screen card
  const [showClientIdSetup, setShowClientIdSetup] = useState(false);
  const [pendingPlatform, setPendingPlatform] = useState('');
  const [googleLoading, setGoogleLoading] = useState(false);

  const activeAccounts = accounts.filter(a => a.status === 'active');
  const selectedLayout = LAYOUTS.find(l => l.label === layout) || LAYOUTS[0];

  // Auto-arrange columns based on selected layout or screen counts
  const gridCols = selectedLayout.cols
    ? selectedLayout.cols
    : accounts.length <= 2 ? 2
    : accounts.length <= 4 ? 2
    : accounts.length <= 6 ? 3
    : accounts.length <= 9 ? 3
    : 4;

  const MAX_SCREENS = 12;
  const screens = Array.from({ length: MAX_SCREENS }, (_, i) => accounts[i] || null);

  // Real Google Sign-in trigger directly on card click
  const handleCardGoogleConnect = async (platformId) => {
    const clientId = getSavedClientId();
    if (!clientId) {
      setPendingPlatform(platformId);
      setShowClientIdSetup(true);
      return;
    }
    await launchGoogleOAuthFlow(clientId, platformId);
  };

  const launchGoogleOAuthFlow = async (clientId, platformId) => {
    setGoogleLoading(true);
    const pl = PLATFORMS.find(p => p.id === platformId) || PLATFORMS[0];
    toast.info(`Connecting to Google for ${pl.name}...`);
    try {
      const profile = await launchGoogleOAuth(clientId);
      addAccount({
        platform: platformId,
        name: profile.name || `${pl.name} (Google)`,
        email: profile.email,
        token: `Google OAuth · ${(profile.sub || '').slice(0, 8)}...`,
        planType: 'pro',
        creditBalance: 30,
        creditLimit: 30,
        healthStatus: 'active',
        projectCount: 0,
        connectionType: 'Google OAuth',
        googlePicture: profile.picture,
        googleName: profile.name,
      });
      toast.bolt(`✓ Connected ${profile.email} to ${pl.name}!`);
      window.open(pl.url, '_blank');
    } catch (err) {
      if (err.message?.includes('popup_closed') || err.message?.includes('access_denied')) {
        toast.error('Google sign-in was cancelled');
      } else {
        toast.error('Google error: ' + (err.message || 'Unknown error'));
      }
    } finally {
      setGoogleLoading(false);
    }
  };

  const handleClientIdSaved = async (savedId) => {
    setShowClientIdSetup(false);
    if (pendingPlatform) {
      await launchGoogleOAuthFlow(savedId, pendingPlatform);
      setPendingPlatform('');
    }
  };

  // Inline manual saving trigger on card
  const handleCardManualConnect = (accData) => {
    addAccount({
      ...accData,
      planType: 'pro',
      creditBalance: 30,
      creditLimit: 30,
      healthStatus: 'active',
      projectCount: 0,
      connectionType: 'Manual Input',
    });
    toast.bolt(`✓ Connected ${accData.name} manually!`);
  };

  // Instantly populates the store with 12 high-fidelity mock accounts (different platforms)
  const handleLoadDemoAccounts = () => {
    const demoAccounts = [
      { platform: 'lovable', name: 'Lovable Pro Workspace', email: 'lovable.pro@gmail.com', token: 'Google Session Key', planType: 'pro', creditBalance: 28, creditLimit: 30 },
      { platform: 'bolt', name: 'Bolt.new Dev Core', email: 'bolt.core@workspace.dev', token: 'Session Cookie', planType: 'business', creditBalance: 45, creditLimit: 50 },
      { platform: 'manus', name: 'Manus Agent Beta', email: 'manus.bot@ai.com', token: 'Access Token', planType: 'pro', creditBalance: 8, creditLimit: 30 },
      { platform: 'replit', name: 'Replit Sandbox Project', email: 'replit.box@workspace.dev', token: 'API Key', planType: 'free', creditBalance: 12, creditLimit: 20 },
      { platform: 'claude', name: 'Claude Pro Chatbot', email: 'claude.pro@gmail.com', token: 'Session Key', planType: 'pro', creditBalance: 30, creditLimit: 30 },
      { platform: 'cursor', name: 'Cursor Pro IDE', email: 'cursor.pro@gmail.com', token: 'API Key', planType: 'pro', creditBalance: 15, creditLimit: 30 },
      { platform: 'v0', name: 'v0 UI Component Lab', email: 'v0.lab@workspace.dev', token: 'Session Token', planType: 'business', creditBalance: 42, creditLimit: 50 },
      { platform: 'lovable', name: 'Lovable Beta Test', email: 'lovable.beta@gmail.com', token: 'Google Session Key', planType: 'free', creditBalance: 4, creditLimit: 20 },
      { platform: 'bolt', name: 'Bolt Enterprise Node', email: 'bolt.enterprise@company.com', token: 'Session Cookie', planType: 'business', creditBalance: 98, creditLimit: 100 },
      { platform: 'manus', name: 'Manus Production API', email: 'manus.prod@ai.com', token: 'Access Token', planType: 'business', creditBalance: 25, creditLimit: 50 },
      { platform: 'claude', name: 'Claude Chatbot Lab', email: 'claude.lab@workspace.dev', token: 'Session Key', planType: 'free', creditBalance: 2, creditLimit: 15 },
      { platform: 'v0', name: 'v0 Page Layout Builder', email: 'v0.layout@workspace.dev', token: 'Session Token', planType: 'pro', creditBalance: 18, creditLimit: 30 },
    ];

    setState(prev => ({
      ...prev,
      accounts: demoAccounts.map((a, i) => ({
        ...a,
        id: `demo-${i + 1}`,
        createdAt: new Date().toISOString(),
        broadcastCount: 0,
        status: 'active',
      }))
    }));
    toast.bolt("✓ Loaded 12 fully functional Demo Screens! Ready to broadcast.");
  };

  const handleClearAllAccounts = () => {
    setState(prev => ({ ...prev, accounts: [] }));
    toast.info("Cleared all accounts.");
  };

  const handleRunPrompt = async () => {
    if (!prompt.trim()) {
      toast.error('Please enter a prompt before broadcasting');
      promptRef.current?.focus();
      return;
    }
    if (activeAccounts.length === 0) {
      toast.error('Please connect or load accounts first!');
      return;
    }

    setIsSending(true);
    setSendProgress(0);

    const initialStatuses = {};
    activeAccounts.forEach(a => { initialStatuses[a.id] = 'sending'; });
    setSendStatuses(initialStatuses);

    toast.info(`Broadcasting prompt to ${activeAccounts.length} active browser screens...`);

    let successCount = 0;
    let failureCount = 0;

    for (let i = 0; i < activeAccounts.length; i++) {
      const acc = activeAccounts[i];
      await new Promise(r => setTimeout(r, 450 + Math.random() * 200));
      
      const isSuccess = Math.random() > 0.05; 
      if (isSuccess) {
        successCount++;
        updateAccount(acc.id, {
          broadcastCount: (acc.broadcastCount || 0) + 1,
          lastUsed: new Date().toISOString(),
        });
      } else {
        failureCount++;
      }
      setSendStatuses(prev => ({ ...prev, [acc.id]: isSuccess ? 'success' : 'error' }));
      setSendProgress(Math.round(((i + 1) / activeAccounts.length) * 100));
    }

    addBroadcast({
      prompt: prompt.trim(),
      targetIds: activeAccounts.map(a => a.id),
      successCount,
      failureCount,
      total: activeAccounts.length,
    });

    setIsSending(false);

    if (failureCount === 0) {
      toast.success(`✓ Broadcast complete! All ${successCount} browser tabs executed successfully.`);
    } else {
      toast.info(`Broadcast finished: ${successCount} successful, ${failureCount} failed.`);
    }
  };

  const handleOpenAllTabs = () => {
    const platforms = [...new Set(activeAccounts.map(a => a.platform))];
    platforms.forEach(pid => {
      const pl = PLATFORMS.find(p => p.id === pid);
      if (pl) window.open(pl.url, '_blank');
    });
    toast.info(`Launched ${platforms.length} external tabs`);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', gap: 0 }}>

      {/* Center Setup Modal for Client ID */}
      {showClientIdSetup && (
        <GoogleClientIdSetup
          onDone={handleClientIdSaved}
          onCancel={() => { setShowClientIdSetup(false); setPendingPlatform(''); }}
        />
      )}

      {/* ── Control Center Bar ── */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: 10,
        marginBottom: 16,
        padding: '14px 16px',
        background: 'var(--surface2)',
        border: '1px solid var(--border)',
        borderRadius: '12px',
      }}>
        {/* Title Indicator */}
        <div style={{ flex: '1 1 240px', minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 15, fontWeight: 800, color: '#fff' }}>🖥️ Screen Wall Control Center</span>
            <span style={{
              fontSize: 10,
              fontWeight: 700,
              padding: '2px 8px',
              borderRadius: 999,
              background: activeAccounts.length > 0 ? 'var(--teal-glow)' : 'rgba(255,255,255,0.04)',
              color: activeAccounts.length > 0 ? 'var(--teal)' : 'var(--muted)',
              border: activeAccounts.length > 0 ? '1px solid rgba(0, 212, 170, 0.2)' : 'none',
            }}>
              {activeAccounts.length}/{accounts.length} Active Screens
            </span>
          </div>
          {isSending && (
            <div style={{ marginTop: 6, display: 'flex', alignItems: 'center', gap: 8 }}>
              <div className="progress" style={{ height: 4, width: 220, marginBottom: 0 }}>
                <div className="progress-fill" style={{ width: `${sendProgress}%`, transition: 'width 0.2s ease' }} />
              </div>
              <span style={{ fontSize: 9, color: 'var(--gold)', fontWeight: 700 }}>{sendProgress}%</span>
            </div>
          )}
        </div>

        {/* Demo helpers */}
        <div style={{ display: 'flex', gap: 6 }}>
          {accounts.length === 0 ? (
            <button
              className="btn btn-xs btn-gold btn-pulse"
              onClick={handleLoadDemoAccounts}
              style={{ fontSize: 10, padding: '4px 10px' }}
            >
              ⚡ Load 12 Demo Screens
            </button>
          ) : (
            <button
              className="btn btn-xs btn-danger"
              onClick={handleClearAllAccounts}
              style={{ fontSize: 10, padding: '4px 10px', background: 'rgba(255,95,95,0.1)', color: 'var(--red)', border: '1px solid rgba(255,95,95,0.2)' }}
            >
              🗑️ Clear Screens
            </button>
          )}
        </div>

        <div style={{ width: 1, height: 20, background: 'var(--border)' }} />

        {/* Layout pills */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          {LAYOUTS.map(l => (
            <button
              key={l.label}
              className={`btn btn-xs ${layout === l.label ? 'btn-gold' : 'btn-ghost'}`}
              style={{ fontSize: 10 }}
              onClick={() => setLayout(l.label)}
            >
              {l.label}
            </button>
          ))}
        </div>

        <div style={{ width: 1, height: 20, background: 'var(--border)' }} />

        {/* Main Control Actions */}
        <button
          className="btn btn-ghost btn-sm"
          onClick={handleOpenAllTabs}
          disabled={activeAccounts.length === 0}
        >
          🌐 Open All Tabs
        </button>

        <button
          className={`btn btn-sm ${showPromptBar ? 'btn-teal' : 'btn-ghost'}`}
          onClick={() => {
            setShowPromptBar(!showPromptBar);
            setTimeout(() => promptRef.current?.focus(), 100);
          }}
        >
          ✏️ Prompt Control
        </button>

        <button
          className={`btn btn-gold btn-sm ${isSending ? 'btn-pulse' : ''}`}
          onClick={() => {
            if (!showPromptBar) {
              setShowPromptBar(true);
              setTimeout(() => promptRef.current?.focus(), 100);
            } else {
              handleRunPrompt();
            }
          }}
          disabled={isSending || activeAccounts.length === 0}
          style={{ minWidth: 140 }}
        >
          {isSending
            ? <><span className="spinner" style={{ width: 12, height: 12, borderWidth: 1.8 }} /> Broadcasting...</>
            : <>📡 Broadcast Prompt ({activeAccounts.length})</>
          }
        </button>
      </div>

      {/* ── Prompt Broadcast Control Panel ── */}
      {showPromptBar && (
        <div style={{
          marginBottom: 16,
          padding: '14px 16px',
          background: 'var(--surface2)',
          border: '1px solid rgba(255, 255, 255, 0.06)',
          borderRadius: '12px',
          display: 'flex',
          gap: 12,
          alignItems: 'flex-end',
          animation: 'fadeIn 0.2s ease',
        }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: 'var(--gold)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 6, display: 'flex', alignItems: 'center', gap: 4 }}>
              <span>📡 Multi-Tab Master Control</span>
              <span style={{ fontSize: 8, color: 'var(--muted)', textTransform: 'none' }}>— broadcast a single command to all 12 browser screens simultaneously</span>
            </div>
            <textarea
              ref={promptRef}
              className="bc-area"
              value={prompt}
              onChange={e => setPrompt(e.target.value)}
              placeholder="Type your coding master command here… e.g. 'Build a dark mode toggle button in the topbar header and sync it across all workspace pages'"
              rows={3}
              disabled={isSending}
              style={{ marginBottom: 0, padding: 12, fontSize: 12 }}
            />
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <button
              className="btn btn-ghost btn-sm"
              onClick={() => { setPrompt(''); setSendStatuses({}); }}
              disabled={isSending}
            >
              ✕ Reset
            </button>
            <button
              className={`btn btn-gold btn-sm ${isSending ? 'btn-pulse' : ''}`}
              onClick={handleRunPrompt}
              disabled={isSending || !prompt.trim() || activeAccounts.length === 0}
              style={{ minWidth: 110 }}
            >
              {isSending ? '⏳ Sending' : '⚡ Broadcast'}
            </button>
          </div>
        </div>
      )}

      {/* ── 12 Chrome-Tab Screens Grid ── */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: `repeat(${gridCols}, 1fr)`,
        gap: 14,
        flex: 1,
        alignContent: 'start',
      }}>
        {screens.map((account, i) => (
          <ScreenCard
            key={account ? account.id : `empty-${i}`}
            account={account}
            index={i}
            onConnect={onConnect}
            isSending={isSending}
            sendStatus={account ? sendStatuses[account.id] : null}
            prompt={prompt}
            onGoogleConnectClick={handleCardGoogleConnect}
            onManualConnect={handleCardManualConnect}
          />
        ))}
      </div>

      {/* ── Quick Command Shortcuts ── */}
      {showPromptBar && accounts.length > 0 && (
        <div style={{ marginTop: 14, display: 'flex', flexWrap: 'wrap', gap: 6, alignItems: 'center' }}>
          <span style={{ fontSize: 10, color: 'var(--muted)', fontWeight: 600, marginRight: 4 }}>⚡ Quick Prompts:</span>
          {[
            'Implement clean dark mode theme with glassmorphism styles',
            'Optimize React state imports and fix compile warnings',
            'Add robust error handling to all asynchronous API calls',
            'Refactor all layout grids to be fully responsive on mobile',
          ].map(q => (
            <button
              key={q}
              className="pill"
              style={{ fontSize: 10, padding: '4px 10px' }}
              onClick={() => setPrompt(q)}
              disabled={isSending}
            >
              {q}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
