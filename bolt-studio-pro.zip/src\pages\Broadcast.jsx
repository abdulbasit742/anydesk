import { useState } from 'react';
import { useStore } from '../data/store';
import { PLATFORMS } from '../data/constants';
import { PlatformIcon, StatusBadge } from '../components/PlatformBadge';
import { useToast } from '../components/Toast';
import EmptyState from '../components/EmptyState';

export default function Broadcast() {
  const { accounts, addBroadcast, updateAccount } = useStore();
  const toast = useToast();

  const active = accounts.filter(a => a.status === 'active');

  const [selectedIds, setSelectedIds] = useState([]);
  const [prompt, setPrompt] = useState('');
  const [delay, setDelay] = useState(800);
  const [isSending, setIsSending] = useState(false);
  const [progress, setProgress] = useState(0);
  const [results, setResults] = useState([]);

  const toggleSelect = (id) => {
    setSelectedIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const selectAll = () => {
    if (selectedIds.length === active.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(active.map(a => a.id));
    }
  };

  const clearAll = () => {
    setPrompt('');
    setSelectedIds([]);
    setResults([]);
    setProgress(0);
  };

  const handleSend = async () => {
    if (!prompt.trim() || selectedIds.length === 0) {
      toast.error('Enter a prompt and select at least one account');
      return;
    }

    setIsSending(true);
    setProgress(0);
    setResults([]);

    const total = selectedIds.length;
    const newResults = [];
    let successCount = 0;
    let failureCount = 0;

    for (let i = 0; i < total; i++) {
      const accId = selectedIds[i];
      const acc = accounts.find(a => a.id === accId);
      const pl = PLATFORMS.find(p => p.id === acc?.platform) || PLATFORMS[0];

      // Show "Sending..." state
      setResults(prev => [...prev, { id: accId, name: acc?.name || 'Unknown', platform: pl.name, status: 'sending' }]);

      // Wait for configured delay
      if (delay > 0) {
        await new Promise(r => setTimeout(r, delay));
      }

      // Simulate success/failure (90% success rate)
      const ok = Math.random() < 0.9;

      if (ok) {
        successCount++;
        // Update the account's broadcast count
        updateAccount(accId, { broadcastCount: (acc?.broadcastCount || 0) + 1 });
      } else {
        failureCount++;
      }

      // Update result from "sending" to final state
      setResults(prev =>
        prev.map(r =>
          r.id === accId && r.status === 'sending'
            ? { ...r, status: ok ? 'success' : 'error', message: ok ? 'Delivered' : 'Failed — rate limit or timeout' }
            : r
        )
      );

      newResults.push({ id: accId, ok });
      setProgress(Math.round(((i + 1) / total) * 100));
    }

    // Record the broadcast in store
    addBroadcast({
      id: 'bc_' + Date.now(),
      prompt: prompt.trim(),
      targetIds: selectedIds,
      successCount,
      failureCount,
      total,
      createdAt: new Date().toISOString(),
    });

    setIsSending(false);

    if (failureCount === 0) {
      toast.success(`Broadcast complete — ${successCount}/${total} delivered`);
    } else {
      toast.warning(`Broadcast done — ${successCount} ok, ${failureCount} failed`);
    }
  };

  if (!accounts.length) {
    return (
      <EmptyState icon="📡" title="No accounts to broadcast" subtitle="Connect at least one AI platform account before sending broadcasts." />
    );
  }

  return (
    <>
      {/* Broadcast Card */}
      <div className="card" style={{ marginBottom: 20 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
          <span style={{ fontSize: 22 }}>📡</span>
          <div>
            <div style={{ fontWeight: 700, fontSize: 15 }}>Broadcast Studio</div>
            <div style={{ fontSize: 12, color: 'var(--muted)' }}>
              {selectedIds.length} of {active.length} accounts selected
            </div>
          </div>
        </div>

        <textarea
          className="bc-area"
          placeholder="Enter your prompt here..."
          value={prompt}
          onChange={e => setPrompt(e.target.value)}
          disabled={isSending}
          rows={5}
        />

        {/* Delay Slider */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, margin: '10px 0' }}>
          <label style={{ fontSize: 12, color: 'var(--muted)', whiteSpace: 'nowrap' }}>Delay: {delay}ms</label>
          <input
            type="range"
            min={0}
            max={5000}
            step={100}
            value={delay}
            onChange={e => setDelay(Number(e.target.value))}
            disabled={isSending}
            style={{ flex: 1 }}
          />
        </div>

        {/* Action Buttons */}
        <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
          <button className="btn btn-ghost btn-sm" onClick={clearAll} disabled={isSending}>✕ Clear</button>
          <button className="btn btn-ghost btn-sm" onClick={selectAll} disabled={isSending}>
            {selectedIds.length === active.length ? '☐ Deselect All' : '☑ Select All'}
          </button>
          <div style={{ flex: 1 }} />
          <button
            className="btn btn-gold btn-sm"
            onClick={handleSend}
            disabled={isSending || !prompt.trim() || selectedIds.length === 0}
          >
            {isSending ? '⏳ Sending...' : `📡 Send to ${selectedIds.length}`}
          </button>
        </div>

        {/* Progress Bar */}
        {isSending && (
          <div style={{ marginTop: 12 }}>
            <div style={{ fontSize: 11, color: 'var(--muted)', marginBottom: 4 }}>Progress: {progress}%</div>
            <div className="progress">
              <div className="progress-fill" style={{ width: `${progress}%`, transition: 'width 0.3s ease' }} />
            </div>
          </div>
        )}

        {/* Results */}
        {results.length > 0 && (
          <div style={{ marginTop: 14 }}>
            <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 6, color: 'var(--muted)' }}>Results</div>
            {results.map((r, i) => (
              <div
                key={r.id + '-' + i}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                  padding: '6px 0',
                  borderBottom: '1px solid var(--border)',
                  fontSize: 12,
                }}
              >
                <span style={{ width: 18, textAlign: 'center' }}>
                  {r.status === 'sending' ? '⏳' : r.status === 'success' ? '✅' : '❌'}
                </span>
                <span style={{ flex: 1, fontWeight: 500 }}>{r.name}</span>
                <span style={{ color: 'var(--muted)', fontSize: 11 }}>{r.platform}</span>
                <span style={{
                  fontSize: 11,
                  color: r.status === 'sending' ? 'var(--gold)' : r.status === 'success' ? 'var(--green)' : 'var(--red)',
                }}>
                  {r.status === 'sending' ? 'Sending...' : r.message}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Account Selection */}
      <div className="sec-hdr">
        <span className="sec-lbl">Select Accounts</span>
        <span style={{ fontSize: 11, color: 'var(--muted)' }}>{active.length} active</span>
      </div>

      {active.length === 0 && (
        <div style={{ textAlign: 'center', padding: 24, color: 'var(--muted)', fontSize: 13 }}>
          No active accounts. Enable some accounts first.
        </div>
      )}

      {active.map(a => {
        const pl = PLATFORMS.find(p => p.id === a.platform) || PLATFORMS[0];
        const selected = selectedIds.includes(a.id);
        return (
          <div
            key={a.id}
            className={'bc-acc-check' + (selected ? ' selected' : '')}
            onClick={() => !isSending && toggleSelect(a.id)}
            style={{ cursor: isSending ? 'not-allowed' : 'pointer' }}
          >
            <span className="chk">{selected ? '☑' : '☐'}</span>
            <PlatformIcon platformId={a.platform} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontWeight: 600, fontSize: 13 }}>{a.name}</div>
              <div style={{ fontSize: 11, color: 'var(--muted)' }}>{a.email || pl.name}</div>
            </div>
            <StatusBadge status={a.status} />
          </div>
        );
      })}
    </>
  );
}
