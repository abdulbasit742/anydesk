import { useState, useCallback } from 'react';
import { useStore } from './data/store';
import Sidebar from './components/Sidebar';
import Topbar from './components/Topbar';
import Dashboard from './pages/Dashboard';
import Analytics from './pages/Analytics';
import Accounts from './pages/Accounts';
import Broadcast from './pages/Broadcast';
import Projects from './pages/Projects';
import Workflows from './pages/Workflows';
import Library from './pages/Library';
import Optimizer from './pages/Optimizer';
import History from './pages/History';
import ScreenWall from './pages/ScreenWall';
import AddAccountModal from './modals/AddAccountModal';

const PAGE_TITLES = {
  dashboard: 'Dashboard',
  analytics: 'Analytics',
  accounts: 'My Accounts',
  broadcast: 'Broadcast Studio',
  projects: 'Projects',
  workflows: 'Workflows',
  library: 'Prompt Library',
  optimizer: 'AI Optimizer',
  history: 'Broadcast History',
  screenwall: 'Screen Wall',
};

export default function App() {
  const [page, setPage] = useState('dashboard');
  const [showConnect, setShowConnect] = useState(false);
  const { accounts, exportData } = useStore();

  const onNav = useCallback((p) => setPage(p), []);
  const onConnect = useCallback(() => setShowConnect(true), []);
  const onCloseConnect = useCallback(() => setShowConnect(false), []);

  const renderPage = () => {
    switch (page) {
      case 'dashboard':
        return <Dashboard onNav={onNav} onConnect={onConnect} />;
      case 'analytics':
        return <Analytics onNav={onNav} />;
      case 'accounts':
        return <Accounts onConnect={onConnect} />;
      case 'broadcast':
        return <Broadcast onNav={onNav} />;
      case 'projects':
        return <Projects onNav={onNav} />;
      case 'workflows':
        return <Workflows onNav={onNav} />;
      case 'library':
        return <Library onNav={onNav} />;
      case 'optimizer':
        return <Optimizer onNav={onNav} />;
      case 'history':
        return <History onNav={onNav} />;
      case 'screenwall':
        return <ScreenWall onConnect={onConnect} />;
      default:
        return <Dashboard onNav={onNav} onConnect={onConnect} />;
    }
  };

  return (
    <div className="app">
      <Sidebar
        page={page}
        onNav={onNav}
        accounts={accounts}
        onConnect={onConnect}
      />
      <div className="main">
        <Topbar
          title={PAGE_TITLES[page] || 'Dashboard'}
          onExport={exportData}
          onConnect={onConnect}
        />
        <div className="content">
          {renderPage()}
        </div>
      </div>
      <AddAccountModal open={showConnect} onClose={onCloseConnect} />
    </div>
  );
}
