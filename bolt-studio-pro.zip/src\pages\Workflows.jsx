import { useState } from 'react';
import { useStore } from '../data/store';
import { useToast } from '../components/Toast';
import EmptyState from '../components/EmptyState';

const emptyStep = () => ({ prompt: '', delay: 0 });

export default function Workflows() {
  const { workflows, addWorkflow, updateWorkflow, deleteWorkflow } = useStore();
  const toast = useToast();
  const [showModal, setShowModal] = useState(false);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState({ name: '', desc: '', steps: [emptyStep()] });

  const openAdd = () => {
    setEditId(null);
    setForm({ name: '', desc: '', steps: [emptyStep()] });
    setShowModal(true);
  };

  const openEdit = (w) => {
    setEditId(w.id);
    setForm({
      name: w.name,
      desc: w.desc || '',
      steps: w.steps && w.steps.length ? w.steps.map(s => ({ ...s })) : [emptyStep()],
    });
    setShowModal(true);
  };

  const handleSave = () => {
    if (!form.name.trim()) return;
    const cleaned = {
      ...form,
      steps: form.steps.filter(s => s.prompt.trim()),
    };
    if (editId) {
      updateWorkflow(editId, cleaned);
      toast.success('Workflow updated');
    } else {
      addWorkflow(cleaned);
      toast.bolt('Workflow created');
    }
    setShowModal(false);
  };

  const handleDelete = (id) => {
    deleteWorkflow(id);
    toast.success('Workflow deleted');
  };

  const updateStep = (idx, field, value) => {
    setForm(f => ({
      ...f,
      steps: f.steps.map((s, i) => (i === idx ? { ...s, [field]: value } : s)),
    }));
  };

  const addStep = () => {
    setForm(f => ({ ...f, steps: [...f.steps, emptyStep()] }));
  };

  const removeStep = (idx) => {
    setForm(f => ({
      ...f,
      steps: f.steps.length > 1 ? f.steps.filter((_, i) => i !== idx) : f.steps,
    }));
  };

  if (!workflows.length) {
    return (
      <EmptyState
        icon="🔄"
        title="No workflows yet"
        subtitle="Create multi-step workflows to automate sequential prompts across your accounts."
      >
        <button className="btn btn-gold" onClick={openAdd}>+ New Workflow</button>
      </EmptyState>
    );
  }

  return (
    <>
      <div className="sec-hdr">
        <span className="sec-lbl">{workflows.length} workflows</span>
        <button className="btn btn-gold btn-sm" onClick={openAdd}>+ New Workflow</button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 12 }}>
        {workflows.map(w => (
          <div key={w.id} className="proj-card">
            <div className="card-name">{w.name}</div>
            <div className="card-desc">{w.desc || 'No description'}</div>
            <div className="card-meta" style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 10 }}>
              <span style={{ fontSize: 11, color: 'var(--muted)' }}>
                {(w.steps || []).length} step{(w.steps || []).length !== 1 ? 's' : ''}
              </span>
            </div>
            <div className="card-footer">
              <button className="btn btn-ghost btn-xs" onClick={() => openEdit(w)}>✏ Edit</button>
              <button className="btn btn-danger btn-xs" onClick={() => handleDelete(w.id)}>🗑 Delete</button>
            </div>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()} style={{ maxWidth: 560 }}>
            <div className="modal-title">{editId ? 'Edit Workflow' : 'New Workflow'}</div>

            <div className="form-row">
              <label>Workflow Name *</label>
              <input
                value={form.name}
                onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                placeholder="e.g. Full-Stack Setup"
              />
            </div>

            <div className="form-row">
              <label>Description</label>
              <textarea
                value={form.desc}
                onChange={e => setForm(f => ({ ...f, desc: e.target.value }))}
                placeholder="What does this workflow do?"
                style={{ minHeight: 60 }}
              />
            </div>

            <div className="form-row">
              <label>Steps</label>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 4 }}>
                {form.steps.map((step, idx) => (
                  <div
                    key={idx}
                    style={{
                      display: 'flex', gap: 8, alignItems: 'flex-start',
                      background: 'var(--surface2)', borderRadius: 8, padding: 10,
                    }}
                  >
                    <div style={{
                      width: 26, height: 26, borderRadius: '50%', flexShrink: 0,
                      background: 'var(--gold)', color: '#000', display: 'flex',
                      alignItems: 'center', justifyContent: 'center',
                      fontSize: 12, fontWeight: 700, marginTop: 2,
                    }}>
                      {idx + 1}
                    </div>
                    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 6 }}>
                      <textarea
                        value={step.prompt}
                        onChange={e => updateStep(idx, 'prompt', e.target.value)}
                        placeholder={`Step ${idx + 1} prompt...`}
                        style={{ minHeight: 50, fontSize: 12 }}
                      />
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <label style={{ fontSize: 11, color: 'var(--muted)', margin: 0 }}>Delay (sec):</label>
                        <input
                          type="number"
                          min="0"
                          value={step.delay}
                          onChange={e => updateStep(idx, 'delay', parseInt(e.target.value) || 0)}
                          style={{ width: 70, fontSize: 12 }}
                        />
                      </div>
                    </div>
                    <button
                      className="btn btn-danger btn-xs"
                      onClick={() => removeStep(idx)}
                      style={{ flexShrink: 0, marginTop: 2 }}
                      disabled={form.steps.length <= 1}
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>
              <button className="btn btn-ghost btn-sm" onClick={addStep} style={{ marginTop: 8 }}>
                + Add Step
              </button>
            </div>

            <div className="modal-footer">
              <button className="btn btn-ghost btn-sm" onClick={() => setShowModal(false)}>Cancel</button>
              <button className="btn btn-gold btn-sm" onClick={handleSave}>Save Workflow</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
