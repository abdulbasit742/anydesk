import { useState, useMemo } from 'react';
import { useStore } from '../data/store';
import { PROMPT_CATEGORIES, CAT_COLORS } from '../data/constants';
import { useToast } from '../components/Toast';
import EmptyState from '../components/EmptyState';

export default function Library({ onNav }) {
  const { prompts, addPrompt, updatePrompt, deletePrompt } = useStore();
  const toast = useToast();
  const [showModal, setShowModal] = useState(false);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState({ title: '', category: 'General', prompt: '' });
  const [search, setSearch] = useState('');
  const [filterCat, setFilterCat] = useState('All');

  const filtered = useMemo(() => {
    let list = prompts;
    if (filterCat !== 'All') {
      list = list.filter(p => p.category === filterCat);
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(p =>
        p.title.toLowerCase().includes(q) ||
        p.prompt.toLowerCase().includes(q)
      );
    }
    return list;
  }, [prompts, filterCat, search]);

  const openAdd = () => {
    setEditId(null);
    setForm({ title: '', category: 'General', prompt: '' });
    setShowModal(true);
  };

  const openEdit = (p) => {
    setEditId(p.id);
    setForm({ title: p.title, category: p.category || 'General', prompt: p.prompt });
    setShowModal(true);
  };

  const handleSave = () => {
    if (!form.title.trim() || !form.prompt.trim()) return;
    if (editId) {
      updatePrompt(editId, form);
      toast.success('Prompt updated');
    } else {
      addPrompt(form);
      toast.bolt('Prompt saved to library');
    }
    setShowModal(false);
  };

  const handleDelete = (id) => {
    deletePrompt(id);
    toast.success('Prompt deleted');
  };

  const handleCopy = (text) => {
    navigator.clipboard.writeText(text).then(
      () => toast.success('Copied to clipboard'),
      () => toast.error('Failed to copy')
    );
  };

  const handleUse = (p) => {
    updatePrompt(p.id, { useCount: (p.useCount || 0) + 1 });
    navigator.clipboard.writeText(p.prompt);
    toast.info('Prompt copied — heading to Broadcast');
    onNav('broadcast');
  };

  const truncate = (str, len = 120) =>
    str.length > len ? str.slice(0, len) + '…' : str;

  const formatDate = (iso) => {
    if (!iso) return '';
    const d = new Date(iso);
    return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
  };

  if (!prompts.length) {
    return (
      <EmptyState
        icon="📚"
        title="Prompt Library is empty"
        subtitle="Save reusable prompts to quickly broadcast across your AI coding accounts."
      >
        <button className="btn btn-gold" onClick={openAdd}>+ New Prompt</button>
      </EmptyState>
    );
  }

  return (
    <>
      <div className="sec-hdr">
        <span className="sec-lbl">{prompts.length} prompts</span>
        <button className="btn btn-gold btn-sm" onClick={openAdd}>+ New Prompt</button>
      </div>

      {/* Search & category filter */}
      <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center', marginBottom: 14 }}>
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="🔍 Search prompts..."
          style={{ flex: '1 1 200px', maxWidth: 300 }}
        />
        <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
          <button
            className={`pill ${filterCat === 'All' ? 'on' : ''}`}
            onClick={() => setFilterCat('All')}
          >
            All
          </button>
          {PROMPT_CATEGORIES.map(cat => (
            <button
              key={cat}
              className={`pill ${filterCat === cat ? 'on' : ''}`}
              onClick={() => setFilterCat(cat)}
              style={filterCat === cat ? { borderColor: CAT_COLORS[cat] || 'var(--border)' } : undefined}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Prompt grid */}
      {filtered.length === 0 ? (
        <div style={{ textAlign: 'center', padding: 40, color: 'var(--muted)', fontSize: 13 }}>
          No prompts match your filter.
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 12 }}>
          {filtered.map(p => (
            <div key={p.id} className="proj-card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6 }}>
                <div className="card-name">{p.title}</div>
                <span
                  className="badge"
                  style={{
                    background: (CAT_COLORS[p.category] || '#6b7280') + '22',
                    color: CAT_COLORS[p.category] || '#6b7280',
                    fontSize: 10,
                  }}
                >
                  {p.category || 'General'}
                </span>
              </div>
              <div className="card-desc" style={{ whiteSpace: 'pre-wrap', fontSize: 12 }}>
                {truncate(p.prompt)}
              </div>
              <div className="card-meta" style={{ display: 'flex', gap: 12, marginTop: 10, fontSize: 11, color: 'var(--muted)' }}>
                <span>Used {p.useCount || 0}×</span>
                {p.createdAt && <span>{formatDate(p.createdAt)}</span>}
              </div>
              <div className="card-footer">
                <button className="btn btn-teal btn-xs" onClick={() => handleUse(p)}>📡 Use</button>
                <button className="btn btn-ghost btn-xs" onClick={() => handleCopy(p.prompt)}>📋 Copy</button>
                <button className="btn btn-ghost btn-xs" onClick={() => openEdit(p)}>✏ Edit</button>
                <button className="btn btn-danger btn-xs" onClick={() => handleDelete(p.id)}>🗑</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add / Edit Modal */}
      {showModal && (
        <div className="overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-title">{editId ? 'Edit Prompt' : 'New Prompt'}</div>

            <div className="form-row">
              <label>Title *</label>
              <input
                value={form.title}
                onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
                placeholder="e.g. SaaS Landing Page"
              />
            </div>

            <div className="form-row">
              <label>Category</label>
              <select
                value={form.category}
                onChange={e => setForm(f => ({ ...f, category: e.target.value }))}
              >
                {PROMPT_CATEGORIES.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            <div className="form-row">
              <label>Prompt *</label>
              <textarea
                value={form.prompt}
                onChange={e => setForm(f => ({ ...f, prompt: e.target.value }))}
                placeholder="Enter your reusable prompt here..."
                style={{ minHeight: 120 }}
              />
            </div>

            <div className="modal-footer">
              <button className="btn btn-ghost btn-sm" onClick={() => setShowModal(false)}>Cancel</button>
              <button className="btn btn-gold btn-sm" onClick={handleSave}>Save Prompt</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
