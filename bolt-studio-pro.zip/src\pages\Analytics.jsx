import { useMemo } from 'react';
import { useStore } from '../data/store';
import { PLATFORMS } from '../data/constants';
import { PlatformIcon, StatusBadge } from '../components/PlatformBadge';
import EmptyState from '../components/EmptyState';

function ago(iso) {
  if (!iso) return 'Never';
  const d = (Date.now() - new Date(iso)) / 1000;
  if (d < 60) return 'Just now';
  if (d < 3600) return ~~(d / 60) + 'm ago';
  if (d < 86400) return ~~(d / 3600) + 'h ago';
  return ~~(d / 86400) + 'd ago';
}

function buildHeatmap(broadcasts) {
  const days = 35;
  const now = new Date();
  const grid = Array.from({ length: days }, (_, i) => {
    const d = new Date(now);
    d.setDate(d.getDate() - (days - 1 - i));
    return { date: d.toDateString(), count: 0 };
  });

  broadcasts.forEach(b => {
    if (!b.createdAt) return;
    const key = new Date(b.createdAt).toDateString();
    const cell = grid.find(g => g.date === key);
    if (cell) cell.count++;
  });

  const max = Math.max(1, ...grid.map(g => g.count));
  return grid.map(g => ({
    ...g,
    opacity: g.count === 0 ? 0.08 : 0.2 + (g.count / max) * 0.8,
    label: new Date(g.date).toLocaleDateString('en', { month: 'short', day: 'numeric' }),
  }));
}

function computeAccountUsage(accounts, broadcasts) {
  return accounts.map(acc => {
    const accBroadcasts = broadcasts.filter(b =>
      b.targets && b.targets.some(t => t.accountId === acc.id)
    );
    const lastBc = accBroadcasts.length
      ? accBroadcasts.reduce((latest, b) =>
          new Date(b.createdAt) > new Date(latest.createdAt) ? b : latest
        )
      : null;
    return {
      ...acc,
      broadcastCount: accBroadcasts.length,
      lastUsed: lastBc ? lastBc.createdAt : null,
    };
  });
}

export default function Analytics() {
  const { accounts, broadcasts } = useStore();

  const stats = useMemo(() => {
    const total = broadcasts.length;
    const successful = broadcasts.reduce((s, b) => s + (b.successCount || 0), 0);
    const failed = broadcasts.reduce((s, b) => s + (b.failureCount || 0), 0);
    const totalSends = successful + failed;
    const rate = totalSends > 0 ? ((successful / totalSends) * 100).toFixed(1) : '—';
    return { total, successful, failed, rate };
  }, [broadcasts]);

  const heatmap = useMemo(() => buildHeatmap(broadcasts), [broadcasts]);

  const accountUsage = useMemo(
    () => computeAccountUsage(accounts, broadcasts),
    [accounts, broadcasts]
  );

  if (!broadcasts.length && !accounts.length) {
    return (
      <EmptyState
        icon="📊"
        title="No analytics yet"
        description="Connect accounts and send broadcasts to see analytics data here."
      />
    );
  }

  return (
    <>
      {/* Stats row */}
      <div className="stats-row">
        <div className="stat" style={{ '--ac': 'var(--gold)' }}>
          <div className="lbl">Total Broadcasts</div>
          <div className="val" style={{ color: 'var(--gold)' }}>{stats.total}</div>
          <div className="sub">all time</div>
        </div>
        <div className="stat" style={{ '--ac': 'var(--teal)' }}>
          <div className="lbl">Successful</div>
          <div className="val" style={{ color: 'var(--teal)' }}>{stats.successful}</div>
          <div className="sub">sends delivered</div>
        </div>
        <div className="stat" style={{ '--ac': 'var(--red)' }}>
          <div className="lbl">Failed</div>
          <div className="val" style={{ color: 'var(--red)' }}>{stats.failed}</div>
          <div className="sub">sends failed</div>
        </div>
        <div className="stat" style={{ '--ac': 'var(--blue)' }}>
          <div className="lbl">Success Rate</div>
          <div className="val" style={{ color: 'var(--blue)' }}>{stats.rate}{stats.rate !== '—' ? '%' : ''}</div>
          <div className="sub">delivery rate</div>
        </div>
      </div>

      {/* Heatmap card */}
      <div className="card">
        <div className="card-hdr">
          <span className="card-title">Broadcast Activity (35 days)</span>
        </div>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(7, 1fr)',
            gap: 4,
            marginTop: 8,
          }}
        >
          {heatmap.map((cell, i) => (
            <div
              key={i}
              className="hm-cell"
              title={`${cell.label}: ${cell.count} broadcast${cell.count !== 1 ? 's' : ''}`}
              style={{
                width: '100%',
                aspectRatio: '1',
                borderRadius: 4,
                background: 'var(--gold)',
                opacity: cell.opacity,
                cursor: 'default',
                minHeight: 18,
              }}
            />
          ))}
        </div>
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            marginTop: 8,
            fontSize: 10,
            color: 'var(--muted)',
          }}
        >
          <span>{heatmap[0]?.label}</span>
          <span>Today</span>
        </div>
      </div>

      {/* Account Usage table */}
      <div className="card" style={{ marginTop: 14 }}>
        <div className="card-hdr">
          <span className="card-title">Account Usage</span>
        </div>
        {accountUsage.length ? (
          <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: 4 }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border)' }}>
                <th style={thStyle}>Account</th>
                <th style={{ ...thStyle, textAlign: 'center' }}>Broadcasts</th>
                <th style={{ ...thStyle, textAlign: 'center' }}>Status</th>
                <th style={{ ...thStyle, textAlign: 'right' }}>Last Used</th>
              </tr>
            </thead>
            <tbody>
              {accountUsage.map(a => {
                const pl = PLATFORMS.find(p => p.id === a.platform) || PLATFORMS[0];
                return (
                  <tr key={a.id} style={{ borderBottom: '1px solid var(--border)' }}>
                    <td style={{ padding: '8px 0', display: 'flex', alignItems: 'center', gap: 8 }}>
                      <PlatformIcon platformId={a.platform} size={20} />
                      <div style={{ minWidth: 0 }}>
                        <div style={{ fontSize: 12.5, fontWeight: 600, color: '#e2e2ec', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{a.name}</div>
                        <div style={{ fontSize: 10.5, color: 'var(--muted)' }}>{pl.name}</div>
                      </div>
                    </td>
                    <td style={{ textAlign: 'center', fontSize: 13, fontWeight: 700, color: 'var(--gold)' }}>{a.broadcastCount}</td>
                    <td style={{ textAlign: 'center' }}><StatusBadge status={a.status} /></td>
                    <td style={{ textAlign: 'right', fontSize: 11, color: 'var(--muted)' }}>{ago(a.lastUsed)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        ) : (
          <div style={{ padding: '20px 0', textAlign: 'center', color: 'var(--muted)', fontSize: 12 }}>
            No accounts connected yet
          </div>
        )}
      </div>
    </>
  );
}

const thStyle = {
  padding: '6px 0',
  fontSize: 10.5,
  fontWeight: 600,
  color: 'var(--muted)',
  textTransform: 'uppercase',
  letterSpacing: '.5px',
  textAlign: 'left',
};
