import { useState } from 'react';
import { useStore } from '../data/store';
import { PLATFORMS } from '../data/constants';
import { PlatformIcon } from '../components/PlatformBadge';
import { useToast } from '../components/Toast';
import EmptyState from '../components/EmptyState';

export default function Projects({ onNav }) {
  const { projects, accounts, addProject, updateProject, deleteProject } = useStore();
  const toast = useToast();
  const [showModal, setShowModal] = useState(false);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState({ name: '', desc: '', accountIds: [] });

  const openAdd = () => { setEditId(null); setForm({ name: '', desc: '', accountIds: [] }); setShowModal(true); };
  const openEdit = (p) => { setEditId(p.id); setForm({ name: p.name, desc: p.desc || '', accountIds: p.accountIds || [] }); setShowModal(true); };

  const handleSave = () => {
    if (!form.name.trim()) return;
    if (editId) {
      updateProject(editId, form);
      toast.success('Project updated');
    } else {
      addProject(form);
      toast.bolt('Project created');
    }
    setShowModal(false);
  };

  const handleDelete = (id) => { deleteProject(id); toast.success('Project deleted'); };
  const toggleStatus = (p) => { updateProject(p.id, { status: p.status === 'active' ? 'paused' : 'active' }); };
  const toggleAccInForm = (accId) => {
    setForm(f => ({ ...f, accountIds: f.accountIds.includes(accId) ? f.accountIds.filter(x => x !== accId) : [...f.accountIds, accId] }));
  };

  if (!projects.length) {
    return <EmptyState icon="📁" title="No projects yet" subtitle="Create projects to organise your accounts and broadcast to specific groups."><button className="btn btn-gold" onClick={openAdd}>+ New Project</button></EmptyState>;
  }

  return (
    <>
      <div className="sec-hdr"><span className="sec-lbl">{projects.length} projects</span><button className="btn btn-gold btn-sm" onClick={openAdd}>+ New Project</button></div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 12 }}>
        {projects.map(p => {
          const accs = accounts.filter(a => (p.accountIds || []).includes(a.id));
          return (
            <div key={p.id} className="proj-card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                <div className="card-name">{p.name}</div>
                <span className={`badge ${p.status === 'active' ? 'badge-ok' : 'badge-off'}`}>{p.status === 'active' ? '● Active' : '○ Paused'}</span>
              </div>
              <div className="card-desc">{p.desc || 'No description'}</div>
              <div className="card-meta" style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 10 }}>
                {accs.slice(0, 5).map(a => <PlatformIcon key={a.id} platformId={a.platform} size={20} />)}
                {accs.length > 5 && <div style={{ width: 20, height: 20, background: 'var(--surface3)', borderRadius: 5, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9, color: 'var(--muted)' }}>+{accs.length - 5}</div>}
                {!accs.length && <span style={{ fontSize: 11, color: 'var(--muted)' }}>No accounts linked</span>}
              </div>
              <div className="card-footer">
                <button className="btn btn-teal btn-xs" onClick={() => onNav('broadcast')}>📡 Broadcast</button>
                <button className="btn btn-ghost btn-xs" onClick={() => openEdit(p)}>✏ Edit</button>
                <button className="btn btn-ghost btn-xs" onClick={() => toggleStatus(p)}>{p.status === 'active' ? '⏸' : '▶'}</button>
                <button className="btn btn-danger btn-xs" onClick={() => handleDelete(p.id)}>🗑</button>
              </div>
            </div>
          );
        })}
      </div>

      {showModal && (
        <div className="overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-title">{editId ? 'Edit Project' : 'New Project'}</div>
            <div className="form-row"><label>Project Name *</label><input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="e.g. SaaS Dashboard" /></div>
            <div className="form-row"><label>Description</label><textarea value={form.desc} onChange={e => setForm(f => ({ ...f, desc: e.target.value }))} placeholder="What is this project about?" style={{ minHeight: 70 }} /></div>
            <div className="form-row">
              <label>Link to Accounts</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 4 }}>
                {accounts.map(a => (
                  <button key={a.id} className={`pill ${form.accountIds.includes(a.id) ? 'on' : ''}`} onClick={() => toggleAccInForm(a.id)}>
                    {(PLATFORMS.find(p => p.id === a.platform) || PLATFORMS[0]).icon} {a.name}
                  </button>
                ))}
                {!accounts.length && <span style={{ fontSize: 12, color: 'var(--muted)' }}>No accounts to link</span>}
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-ghost btn-sm" onClick={() => setShowModal(false)}>Cancel</button>
              <button className="btn btn-gold btn-sm" onClick={handleSave}>Save Project</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
