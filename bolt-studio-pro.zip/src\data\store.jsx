/* eslint-disable react-refresh/only-export-components */
import { createContext, useContext, useState, useCallback } from 'react';

const STORAGE_KEY = 'bolt_studio_pro_v2';

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

function saveState(state) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

const DEFAULT_STATE = {
  accounts: [],
  projects: [],
  workflows: [],
  prompts: [],
  broadcasts: [],
  optimizations: [],
  settings: { delay: 300 },
};

const StoreContext = createContext(null);

export function StoreProvider({ children }) {
  const [state, setStateRaw] = useState(() => loadState() || DEFAULT_STATE);

  const setState = useCallback((updater) => {
    setStateRaw(prev => {
      const next = typeof updater === 'function' ? updater(prev) : updater;
      saveState(next);
      return next;
    });
  }, []);

  // Helper methods
  const addAccount = useCallback((account) => {
    setState(prev => ({ ...prev, accounts: [...prev.accounts, { ...account, id: genId(), createdAt: new Date().toISOString(), broadcastCount: 0, status: 'active' }] }));
  }, [setState]);

  const updateAccount = useCallback((id, updates) => {
    setState(prev => ({ ...prev, accounts: prev.accounts.map(a => a.id === id ? { ...a, ...updates } : a) }));
  }, [setState]);

  const deleteAccount = useCallback((id) => {
    setState(prev => ({ ...prev, accounts: prev.accounts.filter(a => a.id !== id) }));
  }, [setState]);

  const addProject = useCallback((project) => {
    setState(prev => ({ ...prev, projects: [...prev.projects, { ...project, id: genId(), createdAt: new Date().toISOString(), status: 'active' }] }));
  }, [setState]);

  const updateProject = useCallback((id, updates) => {
    setState(prev => ({ ...prev, projects: prev.projects.map(p => p.id === id ? { ...p, ...updates } : p) }));
  }, [setState]);

  const deleteProject = useCallback((id) => {
    setState(prev => ({ ...prev, projects: prev.projects.filter(p => p.id !== id) }));
  }, [setState]);

  const addWorkflow = useCallback((workflow) => {
    setState(prev => ({ ...prev, workflows: [...prev.workflows, { ...workflow, id: genId(), createdAt: new Date().toISOString() }] }));
  }, [setState]);

  const updateWorkflow = useCallback((id, updates) => {
    setState(prev => ({ ...prev, workflows: prev.workflows.map(w => w.id === id ? { ...w, ...updates } : w) }));
  }, [setState]);

  const deleteWorkflow = useCallback((id) => {
    setState(prev => ({ ...prev, workflows: prev.workflows.filter(w => w.id !== id) }));
  }, [setState]);

  const addPrompt = useCallback((prompt) => {
    setState(prev => ({ ...prev, prompts: [...prev.prompts, { ...prompt, id: genId(), createdAt: new Date().toISOString(), useCount: 0 }] }));
  }, [setState]);

  const updatePrompt = useCallback((id, updates) => {
    setState(prev => ({ ...prev, prompts: prev.prompts.map(p => p.id === id ? { ...p, ...updates } : p) }));
  }, [setState]);

  const deletePrompt = useCallback((id) => {
    setState(prev => ({ ...prev, prompts: prev.prompts.filter(p => p.id !== id) }));
  }, [setState]);

  const addBroadcast = useCallback((broadcast) => {
    setState(prev => ({
      ...prev,
      broadcasts: [{ ...broadcast, id: genId(), createdAt: new Date().toISOString() }, ...prev.broadcasts],
      accounts: prev.accounts.map(a => {
        if (broadcast.targetIds?.includes(a.id)) {
          return { ...a, broadcastCount: (a.broadcastCount || 0) + 1, lastUsed: new Date().toISOString() };
        }
        return a;
      })
    }));
  }, [setState]);

  const updateSettings = useCallback((updates) => {
    setState(prev => ({ ...prev, settings: { ...prev.settings, ...updates } }));
  }, [setState]);

  const exportData = useCallback(() => {
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bolt-studio-pro-export-${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }, [state]);

  const value = {
    ...state, setState,
    addAccount, updateAccount, deleteAccount,
    addProject, updateProject, deleteProject,
    addWorkflow, updateWorkflow, deleteWorkflow,
    addPrompt, updatePrompt, deletePrompt,
    addBroadcast, updateSettings, exportData,
  };

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
}

function genId() {
  return Math.random().toString(36).slice(2, 10);
}
