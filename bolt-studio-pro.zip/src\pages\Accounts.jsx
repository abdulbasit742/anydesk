import { useState, useMemo } from 'react';
import { useStore } from '../data/store';
import { PLATFORMS } from '../data/constants';
import { PlatformIcon, StatusBadge } from '../components/PlatformBadge';
import { useToast } from '../components/Toast';
import EmptyState from '../components/EmptyState';

function ago(iso) {
  if (!iso) return 'Never';
  const d = (Date.now() - new Date(iso)) / 1000;
  if (d < 60) return 'Just now';
  if (d < 3600) return ~~(d / 60) + 'm ago';
  if (d < 86400) return ~~(d / 3600) + 'h ago';
  return ~~(d / 86400) + 'd ago';
}

export default function Accounts({ onConnect }) {
  const { accounts, updateAccount, deleteAccount } = useStore();
  const toast = useToast();
  
  // State for view preferences & filters
  const [showPlatformOverview, setShowPlatformOverview] = useState(true);
  const [viewMode, setViewMode] = useState('grid'); // 'grid' | 'list'
  const [searchQuery, setSearchQuery] = useState('');
  const [platformFilter, setPlatformFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  
  // Modals state
  const [confirmDel, setConfirmDel] = useState(null);
  const [editAcc, setEditAcc] = useState(null);
  const [syncingId, setSyncingId] = useState(null);

  // Compute platform connection counts
  const platformCounts = useMemo(() => {
    const counts = {};
    PLATFORMS.forEach(p => {
      counts[p.id] = accounts.filter(a => a.platform === p.id).length;
    });
    return counts;
  }, [accounts]);

  // Filter accounts list
  const filteredAccounts = useMemo(() => {
    return accounts.filter(a => {
      const pl = PLATFORMS.find(p => p.id === a.platform) || PLATFORMS[0];
      const matchesSearch = 
        a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (a.email && a.email.toLowerCase().includes(searchQuery.toLowerCase())) ||
        pl.name.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesPlatform = platformFilter === 'all' || a.platform === platformFilter;
      const matchesStatus = statusFilter === 'all' || a.status === statusFilter;
      
      return matchesSearch && matchesPlatform && matchesStatus;
    });
  }, [accounts, searchQuery, platformFilter, statusFilter]);

  const toggleStatus = (id) => {
    const acc = accounts.find(a => a.id === id);
    const newStatus = acc.status === 'active' ? 'inactive' : 'active';
    updateAccount(id, { status: newStatus });
    toast.success(newStatus === 'active' ? `Enabled ${acc.name}` : `Paused ${acc.name}`);
  };

  const handleSync = async (id) => {
    const acc = accounts.find(a => a.id === id);
    if (!acc) return;
    setSyncingId(id);
    toast.info(`Connecting to ${acc.name}...`);
    
    // Simulate active sync verification
    await new Promise(r => setTimeout(r, 1500));
    
    // Update random values for demo interactivity
    const creditDelta = Math.floor(Math.random() * 5) - 2;
    const newCredits = Math.max(0, Math.min(acc.creditLimit || 30, (acc.creditBalance || 20) + creditDelta));
    
    updateAccount(id, {
      creditBalance: newCredits,
      status: 'active',
      lastSync: new Date().toISOString()
    });
    
    setSyncingId(null);
    toast.bolt(`Synced ${acc.name} — status is Active`);
  };

  const handleDelete = (id) => {
    const acc = accounts.find(a => a.id === id);
    deleteAccount(id);
    toast.success(`Removed account ${acc?.name}`);
    setConfirmDel(null);
  };

  const handleSaveEdit = (e) => {
    e.preventDefault();
    if (!editAcc.name.trim()) return;
    updateAccount(editAcc.id, {
      name: editAcc.name.trim(),
      email: editAcc.email.trim() || null,
      planType: editAcc.planType,
      creditBalance: Number(editAcc.creditBalance),
      creditLimit: Number(editAcc.creditLimit),
    });
    toast.success(`Updated details for ${editAcc.name}`);
    setEditAcc(null);
  };

  if (!accounts.length) {
    return (
      <EmptyState icon="🔌" title="No accounts connected" subtitle="Connect your AI platform accounts to manage limits, monitor usage, and broadcast prompts.">
        <button className="btn btn-gold" onClick={onConnect}>⚡ Connect Account</button>
      </EmptyState>
    );
  }

  return (
    <>
      {/* Header Panel */}
      <div className="sec-hdr" style={{ marginBottom: 14 }}>
        <div>
          <span className="sec-lbl">{accounts.length} Accounts Connected</span>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button 
            className="btn btn-ghost btn-sm" 
            onClick={() => setShowPlatformOverview(!showPlatformOverview)}
          >
            {showPlatformOverview ? '👁️ Hide Overview' : '👁️ Show Overview'}
          </button>
          <button 
            className="btn btn-ghost btn-sm" 
            onClick={() => { 
              accounts.forEach(a => updateAccount(a.id, { status: 'active' })); 
              toast.success('Enabled all accounts'); 
            }}
          >
            ▶ Enable All
          </button>
          <button 
            className="btn btn-ghost btn-sm" 
            onClick={() => { 
              accounts.forEach(a => updateAccount(a.id, { status: 'inactive' })); 
              toast.info('Paused all accounts'); 
            }}
          >
            ⏸ Pause All
          </button>
          <button className="btn btn-gold btn-sm" onClick={onConnect}>⚡ Connect Account</button>
        </div>
      </div>

      {/* Platform Overview Grid */}
      {showPlatformOverview && (
        <div style={{ marginBottom: 20 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: 10 }}>
            {PLATFORMS.map(p => (
              <div
                key={p.id}
                className="card"
                style={{
                  padding: 12,
                  borderTop: `3px solid ${p.color}`,
                  cursor: 'pointer',
                  position: 'relative'
                }}
                onClick={() => window.open(p.url, '_blank')}
              >
                <div style={{ fontSize: 26, marginBottom: 4 }}>{p.icon}</div>
                <p style={{ margin: 0, fontSize: 13, fontWeight: 700, color: p.color }}>{p.name}</p>
                <p style={{ margin: '2px 0 0', fontSize: 11, color: 'var(--muted)' }}>
                  {platformCounts[p.id]} account{platformCounts[p.id] !== 1 ? 's' : ''} connected
                </p>
                <div style={{ marginTop: 6, fontSize: 10, color: p.color, fontWeight: 600 }}>
                  Open Website ↗
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="card" style={{ padding: '12px 16px', marginBottom: 16 }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, alignItems: 'center', justifyContent: 'space-between' }}>
          
          {/* Search Input */}
          <div style={{ flex: 1, minWidth: 200, position: 'relative' }}>
            <input
              type="text"
              placeholder="🔍 Search accounts by name, email, platform..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              style={{ width: '100%', padding: '7px 10px', fontSize: 13 }}
            />
          </div>

          {/* Platform Filter Select */}
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <span style={{ fontSize: 12, color: 'var(--muted)' }}>Platform:</span>
            <select
              value={platformFilter}
              onChange={e => setPlatformFilter(e.target.value)}
              style={{ padding: '6px 10px', fontSize: 12, width: 120 }}
            >
              <option value="all">All Platforms</option>
              {PLATFORMS.map(p => (
                <option key={p.id} value={p.id}>{p.icon} {p.name}</option>
              ))}
            </select>
          </div>

          {/* Status Filter Select */}
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <span style={{ fontSize: 12, color: 'var(--muted)' }}>Status:</span>
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              style={{ padding: '6px 10px', fontSize: 12, width: 110 }}
            >
              <option value="all">All Statuses</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
              <option value="low_credits">Low Credits</option>
              <option value="expired_session">Expired Session</option>
            </select>
          </div>

          {/* Grid vs List Toggler */}
          <div style={{ display: 'flex', border: '1px solid var(--border)', borderRadius: 6, overflow: 'hidden' }}>
            <button 
              className="btn btn-sm" 
              onClick={() => setViewMode('grid')}
              style={{ 
                borderRadius: 0, 
                padding: '6px 12px',
                background: viewMode === 'grid' ? 'var(--gold)' : 'transparent',
                color: viewMode === 'grid' ? '#000' : 'var(--muted2)',
                border: 'none'
              }}
            >
              田 Grid
            </button>
            <button 
              className="btn btn-sm" 
              onClick={() => setViewMode('list')}
              style={{ 
                borderRadius: 0, 
                padding: '6px 12px',
                background: viewMode === 'list' ? 'var(--gold)' : 'transparent',
                color: viewMode === 'list' ? '#000' : 'var(--muted2)',
                border: 'none'
              }}
            >
              ☰ List
            </button>
          </div>

        </div>
      </div>

      {/* Main accounts display list/grid */}
      {filteredAccounts.length === 0 ? (
        <div className="card" style={{ padding: '40px 20px', textAlign: 'center' }}>
          <div style={{ fontSize: 36, marginBottom: 8 }}>🔍</div>
          <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 4 }}>No accounts match the filters</div>
          <div style={{ fontSize: 12, color: 'var(--muted)' }}>Try resetting the search query or status filters.</div>
          <button 
            className="btn btn-ghost btn-sm" 
            style={{ marginTop: 12 }} 
            onClick={() => { setSearchQuery(''); setPlatformFilter('all'); setStatusFilter('all'); }}
          >
            Clear Filters
          </button>
        </div>
      ) : viewMode === 'grid' ? (
        <div className="acc-grid">
          {filteredAccounts.map(a => {
            const pl = PLATFORMS.find(p => p.id === a.platform) || PLATFORMS[0];
            const creditPct = a.creditLimit > 0 ? Math.min(100, Math.round((a.creditBalance / a.creditLimit) * 100)) : 0;
            const isSyncing = syncingId === a.id;
            
            return (
              <div key={a.id} className="acc-card">
                <div className="acc-top">
                  <PlatformIcon platformId={a.platform} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div className="acc-name">{a.name}</div>
                    <div className="acc-sub">{a.email || pl.name}</div>
                  </div>
                  <StatusBadge status={a.status} />
                </div>
                
                {a.creditLimit > 0 && (
                  <div style={{ marginBottom: 12 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: 'var(--muted)', marginBottom: 4 }}>
                      <span>Usage Credits</span>
                      <span style={{ fontWeight: 600, color: pl.color }}>{a.creditBalance} / {a.creditLimit} ({creditPct}%)</span>
                    </div>
                    <div className="progress">
                      <div 
                        className="progress-fill" 
                        style={{ 
                          width: `${creditPct}%`, 
                          background: creditPct < 20 ? 'var(--red)' : creditPct < 50 ? 'var(--gold)' : `linear-gradient(90deg, var(--gold), var(--teal))` 
                        }} 
                      />
                    </div>
                  </div>
                )}
                
                <div style={{ fontSize: 11, color: 'var(--muted)', display: 'flex', flexDirection: 'column', gap: 2, marginBottom: 12 }}>
                  <div>📅 Connected: <strong>{ago(a.createdAt)}</strong></div>
                  <div>📡 Broadcasts sent: <strong>{a.broadcastCount || 0}</strong></div>
                  {a.lastSync && <div>🔄 Last Synced: <strong>{ago(a.lastSync)}</strong></div>}
                </div>

                <div className="acc-actions" style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                  <button 
                    className="btn btn-ghost btn-xs" 
                    onClick={() => toggleStatus(a.id)}
                    style={{ flex: 1 }}
                  >
                    {a.status === 'active' ? '⏸️ Pause' : '▶️ Resume'}
                  </button>
                  <button 
                    className={`btn btn-ghost btn-xs ${isSyncing ? 'btn-pulse' : ''}`}
                    onClick={() => handleSync(a.id)}
                    disabled={isSyncing}
                    style={{ flex: 1 }}
                  >
                    {isSyncing ? '⏳ Syncing' : '🔄 Sync'}
                  </button>
                  <button 
                    className="btn btn-ghost btn-xs" 
                    onClick={() => setEditAcc({ ...a })}
                  >
                    ✏️ Edit
                  </button>
                  <button 
                    className="btn btn-danger btn-xs" 
                    onClick={() => setConfirmDel(a.id)}
                  >
                    🗑️ Remove
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* List Mode View */
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {filteredAccounts.map(a => {
            const pl = PLATFORMS.find(p => p.id === a.platform) || PLATFORMS[0];
            const creditPct = a.creditLimit > 0 ? Math.min(100, Math.round((a.creditBalance / a.creditLimit) * 100)) : 0;
            const isSyncing = syncingId === a.id;
            
            return (
              <div 
                key={a.id} 
                className="card" 
                style={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  gap: 16, 
                  padding: '10px 14px', 
                  flexWrap: 'wrap',
                  borderLeft: `3px solid ${a.status === 'active' ? 'var(--teal)' : 'var(--muted)'}`
                }}
              >
                {/* Platform Avatar */}
                <PlatformIcon platformId={a.platform} size={28} />
                
                {/* Account Name and details */}
                <div style={{ flex: '1 1 200px', minWidth: 150 }}>
                  <div style={{ fontWeight: 700, fontSize: 13, color: '#e2e2ec' }}>{a.name}</div>
                  <div style={{ fontSize: 11, color: 'var(--muted)' }}>{a.email || pl.name} ({pl.name})</div>
                </div>

                {/* Status Badge */}
                <div style={{ flex: '0 0 100px' }}>
                  <StatusBadge status={a.status} />
                </div>

                {/* Credits Progress */}
                {a.creditLimit > 0 ? (
                  <div style={{ flex: '1 1 180px', minWidth: 120 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10, color: 'var(--muted)', marginBottom: 2 }}>
                      <span>Credits</span>
                      <span>{a.creditBalance}/{a.creditLimit} ({creditPct}%)</span>
                    </div>
                    <div className="progress" style={{ height: 6 }}>
                      <div 
                        className="progress-fill" 
                        style={{ 
                          width: `${creditPct}%`, 
                          background: creditPct < 20 ? 'var(--red)' : creditPct < 50 ? 'var(--gold)' : 'var(--teal)' 
                        }} 
                      />
                    </div>
                  </div>
                ) : (
                  <div style={{ flex: '1 1 180px', minWidth: 120, fontSize: 11, color: 'var(--muted)' }}>Unlimited credits</div>
                )}

                {/* Metadata info */}
                <div style={{ flex: '1 1 150px', fontSize: 11, color: 'var(--muted)' }}>
                  <div>📅 Conn: {ago(a.createdAt)}</div>
                  <div>📡 Broadcasts: {a.broadcastCount || 0}</div>
                </div>

                {/* Action buttons */}
                <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                  <button 
                    className="btn btn-ghost btn-xs" 
                    onClick={() => toggleStatus(a.id)}
                  >
                    {a.status === 'active' ? '⏸️' : '▶️'}
                  </button>
                  <button 
                    className={`btn btn-ghost btn-xs ${isSyncing ? 'btn-pulse' : ''}`}
                    onClick={() => handleSync(a.id)}
                    disabled={isSyncing}
                  >
                    {isSyncing ? '⏳' : '🔄'}
                  </button>
                  <button 
                    className="btn btn-ghost btn-xs" 
                    onClick={() => setEditAcc({ ...a })}
                  >
                    ✏️ Edit
                  </button>
                  <button 
                    className="btn btn-danger btn-xs" 
                    onClick={() => setConfirmDel(a.id)}
                  >
                    🗑️
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Edit Details Modal */}
      {editAcc && (
        <div className="overlay" onClick={() => setEditAcc(null)}>
          <div className="modal" onClick={e => e.stopPropagation()} style={{ maxWidth: 440 }}>
            <div className="modal-title">✏️ Edit Account Settings</div>
            
            <form onSubmit={handleSaveEdit}>
              <div className="form-row">
                <label>Account Label / Name</label>
                <input 
                  type="text" 
                  value={editAcc.name} 
                  onChange={e => setEditAcc({ ...editAcc, name: e.target.value })}
                  placeholder="e.g. My Workspace Account"
                  required
                />
              </div>

              <div className="form-row">
                <label>Email Address</label>
                <input 
                  type="email" 
                  value={editAcc.email || ''} 
                  onChange={e => setEditAcc({ ...editAcc, email: e.target.value })}
                  placeholder="yourname@gmail.com"
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
                <div className="form-row">
                  <label>Plan Type</label>
                  <select 
                    value={editAcc.planType || 'free'}
                    onChange={e => setEditAcc({ ...editAcc, planType: e.target.value })}
                  >
                    <option value="free">Free</option>
                    <option value="pro">Pro</option>
                    <option value="business">Business</option>
                  </select>
                </div>
                <div className="form-row">
                  <label>Credits Bal</label>
                  <input 
                    type="number" 
                    value={editAcc.creditBalance || 0} 
                    onChange={e => setEditAcc({ ...editAcc, creditBalance: e.target.value })}
                    min="0"
                  />
                </div>
                <div className="form-row">
                  <label>Credit Limit</label>
                  <input 
                    type="number" 
                    value={editAcc.creditLimit || 0} 
                    onChange={e => setEditAcc({ ...editAcc, creditLimit: e.target.value })}
                    min="0"
                  />
                </div>
              </div>

              <div className="modal-footer" style={{ marginTop: 20 }}>
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => setEditAcc(null)}>Cancel</button>
                <button type="submit" className="btn btn-gold btn-sm">Save Changes</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {confirmDel && (
        <div className="overlay" onClick={() => setConfirmDel(null)}>
          <div className="modal" onClick={e => e.stopPropagation()} style={{ maxWidth: 360, textAlign: 'center' }}>
            <div style={{ fontSize: 32, marginBottom: 8 }}>🗑️</div>
            <div className="modal-title" style={{ textAlign: 'center' }}>Delete this account?</div>
            <p style={{ color: 'var(--muted)', fontSize: 13, marginBottom: 16 }}>
              Are you sure you want to remove this account? This will disconnect it from the dashboard.
            </p>
            <div className="modal-footer" style={{ justifyContent: 'center' }}>
              <button className="btn btn-ghost btn-sm" onClick={() => setConfirmDel(null)}>Cancel</button>
              <button className="btn btn-danger btn-sm" onClick={() => handleDelete(confirmDel)}>Delete</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
