import { useState } from 'react';
import { useStore } from '../data/store';
import { PLATFORMS } from '../data/constants';
import { useToast } from '../components/Toast';
import { getSavedClientId, launchGoogleOAuth } from '../lib/googleAuth';
import GoogleClientIdSetup from './GoogleClientIdSetup';

export default function AddAccountModal({ open, onClose }) {
  const { addAccount } = useStore();
  const toast = useToast();

  // Connection states
  const [platform, setPlatform] = useState('bolt');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [token, setToken] = useState('');
  const [password, setPassword] = useState('');
  const [plan, setPlan] = useState('pro');
  const [creditBal, setCreditBal] = useState(25);
  const [creditLim, setCreditLim] = useState(30);
  const [loading, setLoading] = useState(false);

  // Auth Method: 'token' | 'credentials'
  const [authMethod, setAuthMethod] = useState('token');

  // Real Google OAuth state
  const [googleLoading, setGoogleLoading] = useState(false);
  const [showClientIdSetup, setShowClientIdSetup] = useState(false);

  const p = PLATFORMS.find(x => x.id === platform) || PLATFORMS[0];

  const reset = () => {
    setName('');
    setEmail('');
    setToken('');
    setPassword('');
    setPlatform('bolt');
    setPlan('pro');
    setCreditBal(25);
    setCreditLim(30);
    setAuthMethod('token');
    setGoogleLoading(false);
  };

  const handleSave = async () => {
    if (!name.trim()) {
      toast.error('Please enter an account name');
      return;
    }

    if (authMethod === 'token' && !token.trim()) {
      toast.error(`Please enter your ${p.credLabel}`);
      return;
    }

    if (authMethod === 'credentials' && (!email.trim() || !password.trim())) {
      toast.error('Please enter both email and password');
      return;
    }

    setLoading(true);
    await new Promise(r => setTimeout(r, 1000));

    const securedCred = authMethod === 'token'
      ? '••••' + token.slice(-4)
      : 'Email & Password (secured)';

    addAccount({
      platform,
      name: name.trim(),
      email: email.trim() || 'user@workspace.dev',
      token: securedCred,
      planType: plan,
      creditBalance: creditBal,
      creditLimit: creditLim,
      healthStatus: 'active',
      projectCount: Math.floor(Math.random() * 5) + 1,
      connectionType: authMethod === 'token' ? 'Token' : 'Email/Password',
    });

    toast.bolt(`Successfully connected ${p.name} account!`);
    reset();
    setLoading(false);
    onClose();
  };

  // Real Google OAuth — opens actual Google account picker popup
  const handleRealGoogleOAuth = async () => {
    const clientId = getSavedClientId();
    if (!clientId) {
      // First time — show setup dialog
      setShowClientIdSetup(true);
      return;
    }
    setGoogleLoading(true);
    try {
      const profile = await launchGoogleOAuth(clientId);
      addAccount({
        platform,
        name: profile.name || `${p.name} (Google)`,
        email: profile.email,
        token: `Google OAuth · ${(profile.sub || '').slice(0, 8)}...`,
        planType: 'pro',
        creditBalance: 30,
        creditLimit: 30,
        healthStatus: 'active',
        projectCount: 0,
        connectionType: 'Google OAuth',
        googlePicture: profile.picture,
        googleName: profile.name,
      });
      toast.bolt(`✓ Connected ${profile.email} to ${p.name}!`);
      reset();
      onClose();
      // Open platform so user can also authenticate there
      window.open(p.loginUrl || p.url, '_blank');
    } catch (err) {
      if (err.message?.includes('popup_closed') || err.message?.includes('access_denied')) {
        toast.error('Google sign-in was cancelled');
      } else if (err.message?.includes('not yet loaded')) {
        toast.error('Google SDK loading — please try again in 2 seconds');
      } else {
        toast.error('Google error: ' + (err.message || 'Unknown error'));
      }
    } finally {
      setGoogleLoading(false);
    }
  };

  // Called after user configures Client ID for the first time
  const handleClientIdSaved = async (savedId) => {
    setShowClientIdSetup(false);
    setGoogleLoading(true);
    try {
      const profile = await launchGoogleOAuth(savedId);
      addAccount({
        platform,
        name: profile.name || `${p.name} (Google)`,
        email: profile.email,
        token: `Google OAuth · ${(profile.sub || '').slice(0, 8)}...`,
        planType: 'pro',
        creditBalance: 30,
        creditLimit: 30,
        healthStatus: 'active',
        projectCount: 0,
        connectionType: 'Google OAuth',
        googlePicture: profile.picture,
        googleName: profile.name,
      });
      toast.bolt(`✓ ${profile.email} connected to ${p.name}!`);
      reset();
      onClose();
      window.open(p.loginUrl || p.url, '_blank');
    } catch (err) {
      toast.error('Google auth error: ' + (err.message || 'Please try again'));
    } finally {
      setGoogleLoading(false);
    }
  };

  if (!open) return null;

  // When Google setup is needed, show ONLY that dialog (no z-index conflict)
  if (showClientIdSetup) {
    return (
      <GoogleClientIdSetup
        onDone={handleClientIdSaved}
        onCancel={() => setShowClientIdSetup(false)}
      />
    );
  }

  return (
    <>
      <div className="overlay" onClick={onClose}>
        <div className="modal" onClick={e => e.stopPropagation()} style={{ maxWidth: 460 }}>
          <div className="modal-title">⚡ Connect {p.name} Account</div>

          {/* Wizard progress dots */}
          <div className="wz-dots" style={{ marginBottom: 18 }}>
            <div className="wz-dot done" /><div className="wz-line" />
            <div className="wz-dot active" /><div className="wz-line" />
            <div className="wz-dot" />
          </div>

          {/* Step 1 — Platform selection */}
          <div className="form-row">
            <label>1. Select AI Coding Platform</label>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(105px, 1fr))', gap: 6 }}>
              {PLATFORMS.map(pl => (
                <button
                  key={pl.id}
                  className={`pill ${platform === pl.id ? 'on' : ''}`}
                  onClick={() => {
                    setPlatform(pl.id);
                    if (!name || name.includes('Account')) setName(`${pl.name} Account`);
                  }}
                  style={{ padding: '8px 10px', display: 'flex', alignItems: 'center', gap: 6, justifyContent: 'flex-start', borderRadius: 8, fontSize: 12 }}
                >
                  <span style={{ fontSize: 15 }}>{pl.icon}</span> {pl.name}
                </button>
              ))}
            </div>
          </div>

          <div className="divider" style={{ margin: '14px 0' }} />

          {/* Step 2 — Connection method (vertical column) */}
          <div style={{ marginBottom: 16 }}>
            <label style={{ marginBottom: 8 }}>2. Choose Connection Method</label>

            <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
              <button
                className={`btn btn-sm ${authMethod === 'token' ? 'btn-gold' : 'btn-ghost'}`}
                style={{ flex: 1, justifyContent: 'center' }}
                onClick={() => setAuthMethod('token')}
              >
                🔑 API Token / Cookie
              </button>
              <button
                className={`btn btn-sm ${authMethod === 'credentials' ? 'btn-gold' : 'btn-ghost'}`}
                style={{ flex: 1, justifyContent: 'center' }}
                onClick={() => setAuthMethod('credentials')}
              >
                📧 Email &amp; Password
              </button>
            </div>

            {/* OR divider */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
              <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
              <span style={{ fontSize: 11, color: 'var(--muted)', fontWeight: 600 }}>OR</span>
              <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
            </div>

            {/* Real Google Sign-In button */}
            <button
              type="button"
              disabled={googleLoading}
              onClick={handleRealGoogleOAuth}
              style={{
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 10,
                padding: '10px 16px',
                background: googleLoading ? '#f0f0f0' : '#ffffff',
                color: '#1f1f1f',
                fontFamily: '"Syne", sans-serif',
                fontWeight: 700,
                fontSize: 13,
                border: '1px solid #dadce0',
                borderRadius: 8,
                cursor: googleLoading ? 'not-allowed' : 'pointer',
                boxShadow: '0 2px 6px rgba(0,0,0,0.15)',
                transition: 'all 0.2s ease',
                opacity: googleLoading ? 0.7 : 1,
              }}
              onMouseEnter={e => { if (!googleLoading) { e.currentTarget.style.background = '#f8f9fa'; e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,0.2)'; } }}
              onMouseLeave={e => { e.currentTarget.style.background = googleLoading ? '#f0f0f0' : '#ffffff'; e.currentTarget.style.boxShadow = '0 2px 6px rgba(0,0,0,0.15)'; }}
            >
              {googleLoading ? (
                <>
                  <span className="spinner" style={{ width: 16, height: 16, borderWidth: 2, borderTopColor: '#4285F4', borderColor: '#e0e0e0' }} />
                  Connecting to Google...
                </>
              ) : (
                <>
                  <svg viewBox="0 0 24 24" width="20" height="20" style={{ flexShrink: 0 }}>
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.56-2.77c-.98.66-2.23 1.06-3.72 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                  </svg>
                  Sign in with Google
                  {getSavedClientId() && (
                    <span style={{ fontSize: 10, color: '#34A853', fontWeight: 700 }}>● Ready</span>
                  )}
                </>
              )}
            </button>
          </div>

          <div className="divider" style={{ margin: '14px 0' }} />

          {/* Step 3 — Connection parameters */}
          <div className="form-row">
            <label>3. Connection Parameters</label>
          </div>

          <div className="form-row">
            <label>Account Name / Label *</label>
            <input
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder={`e.g. My ${p.name} Workspace`}
            />
          </div>

          {authMethod === 'token' ? (
            <div className="form-row">
              <label>{p.credLabel} *</label>
              <input
                type="password"
                value={token}
                onChange={e => setToken(e.target.value)}
                placeholder={p.credPlaceholder}
                style={{ fontFamily: 'DM Mono, monospace' }}
              />
              <div className="field-hint">💡 {p.credHelp}</div>
            </div>
          ) : (
            <>
              <div className="form-row">
                <label>Email Address *</label>
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="yourname@gmail.com"
                />
              </div>
              <div className="form-row">
                <label>Password *</label>
                <input
                  type="password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                />
              </div>
            </>
          )}

          {/* Plan / Credits / Limit */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
            <div className="form-row">
              <label>Plan</label>
              <select value={plan} onChange={e => setPlan(e.target.value)}>
                <option value="free">Free</option>
                <option value="pro">Pro</option>
                <option value="business">Business</option>
              </select>
            </div>
            <div className="form-row">
              <label>Credits</label>
              <input type="number" value={creditBal} onChange={e => setCreditBal(Number(e.target.value))} />
            </div>
            <div className="form-row">
              <label>Limit</label>
              <input type="number" value={creditLim} onChange={e => setCreditLim(Number(e.target.value))} />
            </div>
          </div>

          <div className="modal-footer" style={{ marginTop: 14 }}>
            <button className="btn btn-ghost btn-sm" onClick={() => { reset(); onClose(); }}>Cancel</button>
            <button
              className="btn btn-gold btn-sm"
              onClick={handleSave}
              disabled={loading || !name.trim() || (authMethod === 'token' ? !token.trim() : (!email.trim() || !password.trim()))}
            >
              {loading ? '⏳ Verifying...' : `⚡ Connect ${p.name}`}
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
