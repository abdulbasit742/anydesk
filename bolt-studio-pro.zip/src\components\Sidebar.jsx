import { PLATFORMS } from '../data/constants';

const NAV_ITEMS = [
  { section: 'Overview', items: [
    { id: 'dashboard', label: 'Dashboard', icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg> },
    { id: 'analytics', label: 'Analytics', icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg> },
  ]},
  { section: 'Accounts', items: [
    { id: 'accounts', label: 'My Accounts', icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="9" cy="7" r="4"/><path d="M3 21v-2a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2"/><circle cx="19" cy="11" r="2"/><path d="M23 21v-1a2 2 0 0 0-2-2h-1"/></svg> },
    { id: 'broadcast', label: 'Broadcast', icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg> },
    { id: 'screenwall', label: 'Screen Wall', icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg> },
  ]},
  { section: 'Build', items: [
    { id: 'projects', label: 'Projects', icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg> },
    { id: 'workflows', label: 'Workflows', icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14"/><path d="M12 5l7 7-7 7"/></svg> },
  ]},
  { section: 'Prompts', items: [
    { id: 'library', label: 'Prompt Library', icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg> },
    { id: 'optimizer', label: 'AI Optimizer', icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg> },
    { id: 'history', label: 'History', icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="9"/><polyline points="12 6 12 12 16 14"/></svg> },
  ]},
];

export default function Sidebar({ page, onNav, accounts = [], onConnect }) {
  return (
    <div className="sidebar">
      <div className="sb-logo">
        <div className="logo-bolt">⚡</div>
        <div>
          <div className="logo-txt">Bolt Studio</div>
          <div className="logo-sub">Pro · Multi-Platform</div>
        </div>
      </div>
      <div className="sb-nav">
        {NAV_ITEMS.map(section => (
          <div key={section.section}>
            <div className="sb-sect">{section.section}</div>
            {section.items.map(item => (
              <button
                key={item.id}
                className={`nav-btn ${page === item.id ? 'active' : ''}`}
                onClick={() => onNav(item.id)}
              >
                {item.icon}
                {item.label}
              </button>
            ))}
          </div>
        ))}
        {accounts.length > 0 && (
          <>
            <div className="sb-sect" style={{ marginTop: 8 }}>Connected</div>
            <div className="sb-account-list">
              {accounts.map(a => {
                const pl = PLATFORMS.find(p => p.id === a.platform) || PLATFORMS[0];
                return (
                  <div key={a.id} className="sb-acc-item" onClick={() => onNav('accounts')}>
                    <div className="sb-acc-dot" style={{ background: a.status === 'active' ? 'var(--teal)' : a.status === 'expired_session' ? 'var(--red)' : 'var(--muted)' }} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div className="sb-acc-name">{a.name}</div>
                      <div className="sb-acc-plat">{pl.name}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}
      </div>
      <div className="sb-footer">
        <button className="btn btn-gold btn-sm btn-pulse" style={{ width: '100%', justifyContent: 'center' }} onClick={onConnect}>⚡ Connect Account</button>
      </div>
    </div>
  );
}
