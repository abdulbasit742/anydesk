import { useState, useMemo, useCallback } from 'react';
import { useStore } from '../data/store';
import { useToast } from '../components/Toast';
import EmptyState from '../components/EmptyState';

function timeAgo(dateStr) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 30) return `${days}d ago`;
  return `${Math.floor(days / 30)}mo ago`;
}

const FILTERS = [
  { id: 'all', label: 'All' },
  { id: 'today', label: 'Today' },
  { id: 'week', label: 'This Week' },
  { id: 'month', label: 'This Month' },
];

function isInRange(dateStr, filter) {
  if (filter === 'all') return true;
  const now = new Date();
  const d = new Date(dateStr);
  if (filter === 'today') {
    return d.toDateString() === now.toDateString();
  }
  if (filter === 'week') {
    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    return d >= weekAgo;
  }
  if (filter === 'month') {
    const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    return d >= monthAgo;
  }
  return true;
}

const EMPTY_ARRAY = [];

export default function History({ onNav }) {
  const store = useStore();
  const toast = useToast();

  const [filter, setFilter] = useState('all');
  const [expandedId, setExpandedId] = useState(null);

  const broadcasts = store.broadcasts || EMPTY_ARRAY;

  const filtered = useMemo(
    () => broadcasts.filter(b => isInRange(b.createdAt, filter)),
    [broadcasts, filter]
  );

  const handleClearHistory = useCallback(() => {
    if (!broadcasts.length) return;
    store.setState(prev => ({ ...prev, broadcasts: [] }));
    toast.info('Broadcast history cleared');
  }, [broadcasts.length, store, toast]);

  const toggleExpand = useCallback((id) => {
    setExpandedId(prev => (prev === id ? null : id));
  }, []);

  if (!broadcasts.length) {
    return (
      <div>
        <div className="sec-hdr">📜 Broadcast History</div>
        <EmptyState
          icon="📡"
          title="No broadcasts yet"
          subtitle="Send your first broadcast to see it appear here. All past broadcasts will be logged with their results."
        >
          <button className="btn btn-gold" onClick={() => onNav && onNav('broadcast')}>
            ⚡ Go to Broadcast
          </button>
        </EmptyState>
      </div>
    );
  }

  return (
    <div>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <div className="sec-hdr" style={{ marginBottom: 0 }}>📜 Broadcast History</div>
        <button className="btn btn-danger btn-sm" onClick={handleClearHistory}>
          🗑 Clear History
        </button>
      </div>

      {/* Filters */}
      <div className="pills" style={{ marginBottom: 20 }}>
        {FILTERS.map(f => (
          <button
            key={f.id}
            className={`pill ${filter === f.id ? 'active' : ''}`}
            onClick={() => setFilter(f.id)}
          >
            {f.label}
          </button>
        ))}
        <span style={{ fontSize: '0.72rem', color: 'var(--muted)', marginLeft: 8 }}>
          {filtered.length} result{filtered.length !== 1 ? 's' : ''}
        </span>
      </div>

      {/* Broadcast List */}
      <div className="card">
        {filtered.length === 0 ? (
          <div style={{ padding: '32px 0', textAlign: 'center', color: 'var(--muted)', fontSize: '0.85rem' }}>
            No broadcasts match this filter.
          </div>
        ) : (
          filtered.map(b => {
            const successCount = b.results ? b.results.filter(r => r.status === 'success').length : (b.successCount || 0);
            const failCount = b.results ? b.results.filter(r => r.status === 'error').length : (b.failCount || 0);
            const targetCount = b.targetIds ? b.targetIds.length : (b.accountCount || 0);
            const isExpanded = expandedId === b.id;
            const promptText = b.prompt || b.content || '';

            return (
              <div
                key={b.id}
                className="hist-row"
                style={{ flexDirection: 'column', cursor: 'pointer' }}
                onClick={() => toggleExpand(b.id)}
              >
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14, width: '100%' }}>
                  {/* Prompt preview */}
                  <div className="hist-prompt" style={{
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: isExpanded ? 'pre-wrap' : 'nowrap',
                  }}>
                    {isExpanded
                      ? promptText
                      : (promptText.length > 90 ? promptText.slice(0, 90) + '…' : promptText)
                    }
                  </div>

                  {/* Metadata */}
                  <div className="hist-meta" style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 4 }}>
                    <span>{timeAgo(b.createdAt)}</span>
                    <div style={{ display: 'flex', gap: 10, fontSize: '0.7rem' }}>
                      {successCount > 0 && (
                        <span style={{ color: 'var(--teal)' }}>✓ {successCount}</span>
                      )}
                      {failCount > 0 && (
                        <span style={{ color: 'var(--red)' }}>✕ {failCount}</span>
                      )}
                      {targetCount > 0 && (
                        <span style={{ color: 'var(--muted2)' }}>👤 {targetCount}</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Expanded details */}
                {isExpanded && (
                  <div style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid var(--border)', width: '100%' }}>
                    <div className="sec-lbl">Full Prompt</div>
                    <div className="opt-box" style={{ marginBottom: 12 }}>
                      {promptText}
                    </div>
                    <div style={{ display: 'flex', gap: 12, fontSize: '0.75rem', color: 'var(--muted2)' }}>
                      <span>Sent: {new Date(b.createdAt).toLocaleString()}</span>
                      <span>Accounts: {targetCount}</span>
                      <span style={{ color: 'var(--teal)' }}>Success: {successCount}</span>
                      <span style={{ color: 'var(--red)' }}>Failed: {failCount}</span>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
