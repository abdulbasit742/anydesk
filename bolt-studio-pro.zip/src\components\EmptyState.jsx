export default function EmptyState({ icon, title, subtitle, children }) {
  return (
    <div className="empty-state">
      <div className="empty-icon">{icon}</div>
      <div className="empty-title">{title}</div>
      <div className="empty-sub">{subtitle}</div>
      <div className="empty-actions">{children}</div>
    </div>
  );
}
