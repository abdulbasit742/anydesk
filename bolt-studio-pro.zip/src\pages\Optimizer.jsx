import { useState, useCallback } from 'react';
import { useStore } from '../data/store';
import { useToast } from '../components/Toast';

function optimizePrompt(original) {
  return `## Enhanced Prompt

${original}

### Technical Requirements:
- Implement with clean, modular code architecture
- Add comprehensive error handling and loading states
- Ensure full mobile responsiveness (320px - 2560px)
- Follow accessibility best practices (WCAG 2.1 AA)
- Add smooth transitions and micro-animations
- Include proper TypeScript types/interfaces
- Optimize for performance (lazy loading, code splitting)

### Design Specifications:
- Use a modern, premium design system
- Implement dark/light mode support
- Add subtle hover effects and focus states
- Use consistent spacing (8px grid system)

### Quality Assurance:
- Handle edge cases and empty states gracefully
- Add input validation where applicable
- Include loading skeletons for async data`;
}

function timeAgo(dateStr) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

export default function Optimizer({ onNav }) {
  const store = useStore();
  const toast = useToast();

  const [input, setInput] = useState('');
  const [optimized, setOptimized] = useState('');
  const [original, setOriginal] = useState('');
  const [loading, setLoading] = useState(false);

  const optimizations = store.optimizations || [];

  const handleOptimize = useCallback(() => {
    const trimmed = input.trim();
    if (!trimmed) {
      toast.error('Please enter a prompt to optimize');
      return;
    }

    setLoading(true);
    setOriginal(trimmed);
    setOptimized('');

    setTimeout(() => {
      const result = optimizePrompt(trimmed);
      setOptimized(result);
      setLoading(false);

      // Save to optimizations history
      store.setState(prev => ({
        ...prev,
        optimizations: [
          { id: Math.random().toString(36).slice(2, 10), original: trimmed, enhanced: result, createdAt: new Date().toISOString() },
          ...(prev.optimizations || []),
        ],
      }));

      toast.success('Prompt optimized successfully!');
    }, 1500);
  }, [input, store, toast]);

  const handleSaveToLibrary = useCallback(() => {
    if (!optimized) return;
    store.addPrompt({
      name: original.slice(0, 50) + (original.length > 50 ? '…' : ''),
      content: optimized,
      category: 'optimized',
    });
    toast.bolt('Saved to Prompt Library');
  }, [optimized, original, store, toast]);

  const handleUseBroadcast = useCallback(() => {
    if (!optimized) return;
    if (onNav) onNav('broadcast');
  }, [optimized, onNav]);

  const handleLoadFromHistory = useCallback((item) => {
    setInput(item.original);
    setOriginal(item.original);
    setOptimized(item.enhanced);
  }, []);

  return (
    <div>
      <div className="sec-hdr">⚡ AI Prompt Optimizer</div>

      {/* Input Section */}
      <div className="card" style={{ marginBottom: 20 }}>
        <div className="card-hdr">
          <div className="card-title">Original Prompt</div>
          <div style={{ fontSize: '0.72rem', color: 'var(--muted)' }}>
            {input.length} characters
          </div>
        </div>
        <textarea
          className="bc-area"
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Paste your prompt here… e.g. 'Build a todo app with React'"
          rows={5}
        />
        <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
          <button
            className="btn btn-gold"
            onClick={handleOptimize}
            disabled={loading || !input.trim()}
          >
            {loading ? (
              <>
                <span className="spinner" style={{ width: 16, height: 16, borderWidth: 2 }} />
                Optimizing…
              </>
            ) : (
              <>⚡ Optimize</>
            )}
          </button>
          <button
            className="btn btn-ghost"
            onClick={() => { setInput(''); setOptimized(''); setOriginal(''); }}
            disabled={!input && !optimized}
          >
            Clear
          </button>
        </div>
      </div>

      {/* Side-by-side Comparison */}
      {(loading || optimized) && (
        <div className="card" style={{ marginBottom: 20 }}>
          <div className="card-hdr">
            <div className="card-title">Comparison</div>
            {optimized && (
              <div style={{ display: 'flex', gap: 8 }}>
                <button className="btn btn-teal btn-sm" onClick={handleSaveToLibrary}>
                  💾 Save to Library
                </button>
                <button className="btn btn-sm" onClick={handleUseBroadcast}>
                  📡 Use in Broadcast
                </button>
              </div>
            )}
          </div>

          <div className="opt-compare">
            <div>
              <div className="sec-lbl">Original</div>
              <div className="opt-box">{original || '…'}</div>
            </div>
            <div>
              <div className="sec-lbl">Enhanced</div>
              {loading ? (
                <div className="opt-box" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: 180 }}>
                  <div style={{ textAlign: 'center' }}>
                    <div className="spinner" style={{ margin: '0 auto 12px' }} />
                    <div style={{ fontSize: '0.8rem', color: 'var(--muted)' }}>
                      AI is enhancing your prompt…
                    </div>
                  </div>
                </div>
              ) : (
                <div className="opt-box enhanced">{optimized}</div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Optimization History */}
      {optimizations.length > 0 && (
        <div className="card">
          <div className="card-hdr">
            <div className="card-title">Optimization History</div>
            <span style={{ fontSize: '0.72rem', color: 'var(--muted)' }}>
              {optimizations.length} optimization{optimizations.length !== 1 ? 's' : ''}
            </span>
          </div>
          {optimizations.map(item => (
            <div
              key={item.id}
              className="hist-row"
              style={{ cursor: 'pointer' }}
              onClick={() => handleLoadFromHistory(item)}
            >
              <div className="hist-prompt" style={{
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
              }}>
                {item.original.length > 80 ? item.original.slice(0, 80) + '…' : item.original}
              </div>
              <div className="hist-meta">
                {timeAgo(item.createdAt)}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
